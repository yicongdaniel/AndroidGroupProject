package com.cst2335.groupproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This class excutes functionalities in the car database
 */
public class CarDatabase extends AppCompatActivity {
    protected static final String ACTIVITY_NAME = "CarDatabaseActivity";
    private List<CarDatabaseObj> databaseList = new ArrayList<>();
    ListView list;
    MyListAdapter_DB adapter;
    DetailsFragmentCarDB dFragment;
    SQLiteDatabase db;
    /**
     * Loading database method, and add listener to buttons
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_database);
        list = findViewById(R.id.listView_car_db);
        list.setAdapter(adapter = new MyListAdapter_DB());
       // loadDataFromDatabase();
        //initialize database db object
        MyOpenerCar dbOpener = new MyOpenerCar( this);
        db = dbOpener.getWritableDatabase();
        loadDataFromDatabase();


        /**
         * Click on list view shows more details for the car. Go to fragment if it is a tablet, go to next activity if is a phone
         */
        boolean isTablet = findViewById(R.id.fragmentLocation_car) != null;
        list.setOnItemClickListener((list, item, position, id) -> {
            //Create a bundle to pass data to the new fragment
            Bundle dataToPass = new Bundle();
            CarDatabaseObj car = databaseList.get(position);
            dataToPass.putLong("ID", car.getId());
            dataToPass.putString("ModelName", car.getModelName());
            dataToPass.putString("CarMake", car.getMake());
            if (isTablet) {
                dFragment = new DetailsFragmentCarDB();
                dFragment.setArguments( dataToPass ); //pass it a bundle for information
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentLocation_car, dFragment)//call replace()
                        .commit();
            }
            else {//isPhone
                Intent nextActivity = new Intent(CarDatabase.this, EmptyActivityCarDB.class);
                nextActivity.putExtras(dataToPass);
                startActivity(nextActivity);
            }

        });
        /**
         * Long click list item shows up alert dialog then delete car item in the car database
         */
        list.setOnItemLongClickListener((parent, view, position, id)->{
            AlertDialog.Builder alert=new AlertDialog.Builder(this);
            alert.setTitle("Do you want to delete this?").setMessage("The selected row is "+ (position + 1) +", and the database id is "+ id)
                    .setPositiveButton("Yes",(click,arg)->{
                        reomveCar(databaseList.get(position));
                        databaseList.remove(position);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(this, "This car has been removed from the Car Database", Toast.LENGTH_LONG).show();
                    }).setNegativeButton("No",(click,arg)->{}).create().show();
            return true;
        });

    }


    /**
     * Shows the list view in the database
     */
    class MyListAdapter_DB extends BaseAdapter {//For list view
        @Override
        public int getCount() {
            return databaseList.size();
        }
        @Override
        public Object getItem(int position) {
            return databaseList.get(position);
        }
        @Override
        public long getItemId(int position) {
            return databaseList.get(position).getId();
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CarDatabaseObj car = (CarDatabaseObj) getItem(position);
            LayoutInflater inflater = getLayoutInflater();
            //make a new row
            View rowView = inflater.inflate(R.layout.activity_car_list, parent, false);
            TextView carView2 = rowView.findViewById(R.id.car_item);
            carView2.setText(car.getModelName());//the list view will only show the model name of the car
            return rowView;
        }
    }
    /**
     * This function will be called at the beginning
     */
    private void loadDataFromDatabase(){
        MyOpenerCar dbOpener = new MyOpenerCar(this);
        SQLiteDatabase db = dbOpener.getWritableDatabase(); //This calls onCreate() if you've never built the table before, or onUpgrade if the version here is newer

        String [] columns = {MyOpenerCar.COL1, MyOpenerCar.COL2, MyOpenerCar.COL3};
        Cursor results = db.query(false, MyOpenerCar.TABLE_NAME, columns, null, null, null, null, null, null);

        printCursor(results, db.getVersion());//call printCursor function for debug
        int IdColumnIndex = results.getColumnIndex(MyOpenerCar.COL1);
        int ModelColumnIndex = results.getColumnIndex(MyOpenerCar.COL2);
        int MakeColumnIndex = results.getColumnIndex(MyOpenerCar.COL3);

        while(results.moveToNext()) {
            String MODEL = results.getString(ModelColumnIndex);
            String MAKE = results.getString(MakeColumnIndex);
            long id = results.getLong(IdColumnIndex);
            //add the new Contact to the array list:
            databaseList.add(new CarDatabaseObj(MODEL, MAKE, id));
        }

    }
    /**
     * Showing info on debug
     * @param c Cursor
     * @param version is the database version
     */
    private void printCursor(Cursor c, int version){
        Log.e(ACTIVITY_NAME, "DB version: "+ version);
        Log.e(ACTIVITY_NAME, "Number of columns " + c.getColumnCount());
        Log.e(ACTIVITY_NAME, "Name of the colums " + Arrays.toString(c.getColumnNames()));
        Log.e(ACTIVITY_NAME, "Number of rows " + c.getCount());
        Log.e(ACTIVITY_NAME, "Each row results: " );

        while (c.moveToNext()){
            long ID = c.getLong(c.getColumnIndex(MyOpenerCar.COL1));
            String ModelName = c.getString(c.getColumnIndex(MyOpenerCar.COL2));
            String Make = c.getString(c.getColumnIndex(MyOpenerCar.COL3));
            Log.e(ACTIVITY_NAME, ID + "  " + ModelName + "  " + Make);
        }
        c.moveToPosition(-1);
    }
    /**
     * This is the function that excute delete statement in the SQL. It is used to removed a car item
     * @param c is the object of the CarDatabase
     */
    protected void reomveCar(CarDatabaseObj c){
        db.delete(MyOpenerCar.TABLE_NAME, MyOpenerCar.COL1 + "= ?", new String[] {Long.toString(c.getId())});
    }
}