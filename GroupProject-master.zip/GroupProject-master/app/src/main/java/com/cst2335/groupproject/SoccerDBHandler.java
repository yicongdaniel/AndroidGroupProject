package com.cst2335.groupproject;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import java.io.IOException;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;


/**
 * DB handler class
 *
 * @author – Hong Liang
 * @version – 2021.3
 * @param –
 * @return –
 * @since – 1.0
 */
public class SoccerDBHandler extends SQLiteOpenHelper {
    private static String table_name = "soccer";
    private static String id_col = "id";
    private static String socc_Datetime = "Date_time";
    private static String socc_Title = "title";
    private static String socc_Desc = "Description";
    private static String socc_URL = "URL";
    private static String socc_img = "Thumbnail";
    private static int dbVersion;
    public static SQLiteDatabase db;
    public boolean isLoaded;
    Context c;

    /**
     * DB handler constractor
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public SoccerDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        c=context;
        this.dbVersion= version;

        try{
//            db.execSQL("drop table soccer");
//            db.execSQL("drop table favourite_soccer");
            db = this.getWritableDatabase();
            String CREATE_TABLE_soccer = "CREATE TABLE if not exists "+table_name+" (id TEXT,Date_time TEXT, title TEXT, Description TEXT,URL TEXT, Thumbnail TEXT,icon TEXT)";
            db.execSQL(CREATE_TABLE_soccer);

            String CREATE_TABLE_favourite = "CREATE TABLE if not exists favourite_"+table_name+" (id TEXT,Date_time TEXT, title TEXT, Description TEXT,URL TEXT, Thumbnail TEXT,icon TEXT)";
            db.execSQL(CREATE_TABLE_favourite);

             // loadAll();

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public SQLiteDatabase getDB(){
        return db;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    /**
     * DB handler class
     * convert string to xml doc
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    private static Document toXmlDocument(String str) throws ParserConfigurationException, SAXException, IOException {

        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        Document document = docBuilder.parse(new InputSource(new StringReader(str)));

        return document;
    }

    /**
     * DB handler class
     * insert feed to database
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public  void insertFeed(SoccerFeed feed){

         db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try{
            ContentValues cv = new ContentValues();
            cv.put("id", feed.getId());
            cv.put("Date_time", feed.getarticle_date());
            cv.put("title", feed.getTitle());
            cv.put("Description", feed.getarticle_desc());
            cv.put("URL", feed.getarticle_url());
            cv.put("Thumbnail", feed.getimg());
            cv.put("icon", feed.geticon());
            db.insert("soccer", null, cv);

        }catch (Exception e){
            e.printStackTrace();
        }
        // db.execSQL("delete from chat");

    }

    /**
     * DB handler class
     * remove a favourite feed from database
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public  void removeFeedFromFavourite(SoccerFeed feed){

        db = this.getWritableDatabase();
        try{
            db.execSQL("delete from favourite_soccer where id='"+feed.getId()+"'");
        }catch (Exception e){
            e.printStackTrace();
        }


     //   displayAlertdialog("Not Save!","This article is already in your favourite!");

    }

    /**
     * DB handler class
     * insert a favourite feed into database
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public  void insertFeedToFavourite(SoccerFeed feed,int disp){

        String selectQuery = "SELECT * From favourite_soccer";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery,null);
        ContentValues values = new ContentValues();

        Boolean isExist=false;
        if(cursor.moveToFirst()){
            do {

                if(
                    cursor.getString( cursor.getColumnIndex("id")).equals(feed.getId())
                    && cursor.getString( cursor.getColumnIndex("Date_time")).equals(feed.getarticle_date())
                    && cursor.getString( cursor.getColumnIndex("title")).equals(feed.getTitle())
                    && cursor.getString( cursor.getColumnIndex("Description")).equals(feed.getarticle_desc())
                    && cursor.getString( cursor.getColumnIndex("URL")).equals(feed.getarticle_url())
                    && cursor.getString( cursor.getColumnIndex("Thumbnail")).equals(feed.getimg())
                ){
                    isExist=true;
                    break;
                }

            }while (cursor.moveToNext());
        }
        if (!isExist){
            try{
                ContentValues cv = new ContentValues();
                cv.put("id", feed.getId());
                cv.put("Date_time", feed.getarticle_date());
                cv.put("title", feed.getTitle());
                cv.put("Description", feed.getarticle_desc());
                cv.put("URL", feed.getarticle_url());
                cv.put("Thumbnail", feed.getimg());
                cv.put("icon", feed.geticon());
                db.insert("favourite_soccer", null, cv);
                if (disp!=1){
                    displayAlertdialog("Saved","This article has been saved to your favourite!");
                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }else{
            if (disp!=1){
                displayAlertdialog("Not Save!","This article is already in your favourite!");
            }
        }
    }

    /**
     * DB handler class
     * display alertdialog
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    private void displayAlertdialog(String title, String message){
         SoccerDBHandler cnt = this;
        AlertDialog.Builder alert = new AlertDialog.Builder(c);

        //Setting the title manually
        alert.setTitle(title);
        alert.setMessage(message);
        alert.setPositiveButton("OK",null);

        alert.show();
    }

    /**
     * DB handler class
     * encode bitmap to string
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public static String encodeTobase64(Bitmap image) {
        Bitmap immagex = image;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        immagex.compress(Bitmap.CompressFormat.PNG, 90, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);
        return imageEncoded;
    }

    /**
     * DB handler class
     * decode string to bitmap
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public static Bitmap decodeBase64(String input) {
        byte[] decodedByte = Base64.decode(input, 0);
        return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
    }

    /**
     * DB handler class
     * delete a feed from database
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void deleteFeed(SoccerFeed feed){
        SQLiteDatabase db = this.getWritableDatabase();
        //db.execSQL("delete from chat");
        db.execSQL("delete from soccer where id="+feed.getId());
    }

    /**
     * DB handler class
     * retrieve all feeds
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public List<SoccerFeed> getAllFeeds(){
        List<SoccerFeed> feeds = new ArrayList<SoccerFeed>();

        String selectQuery = "SELECT * From soccer";

         db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery,null);

        if(cursor.moveToFirst()){
            do {
                SoccerFeed feed = new SoccerFeed();
                feed.setId(cursor.getString( cursor.getColumnIndex("id") ));
                feed.setarticle_date(cursor.getString( cursor.getColumnIndex("Date_time")));
                feed.setTitle(cursor.getString( cursor.getColumnIndex("title")));
                feed.setarticle_desc(cursor.getString( cursor.getColumnIndex("Description")));
                feed.setarticle_url(cursor.getString( cursor.getColumnIndex("URL")));
                feed.setimg(cursor.getString( cursor.getColumnIndex("Thumbnail")));
                feed.seticon(cursor.getString( cursor.getColumnIndex("icon")));

                feeds.add(feed);
            }while (cursor.moveToNext());
        }

        return feeds;
    }

    /**
     * DB handler class
     * retrieve all favourite feeds
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public List<SoccerFeed> getAllFeedsFavourite(){
        List<SoccerFeed> feeds = new ArrayList<SoccerFeed>();

        String selectQuery = "SELECT * From favourite_soccer";

        db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery,null);

        if(cursor.moveToFirst()){
            do {
                SoccerFeed feed = new SoccerFeed();
                feed.setId(cursor.getString( cursor.getColumnIndex("id") ));
                feed.setarticle_date(cursor.getString( cursor.getColumnIndex("Date_time")));
                feed.setTitle(cursor.getString( cursor.getColumnIndex("title")));
                feed.setarticle_desc(cursor.getString( cursor.getColumnIndex("Description")));
                feed.setarticle_url(cursor.getString( cursor.getColumnIndex("URL")));
                feed.setimg(cursor.getString( cursor.getColumnIndex("Thumbnail")));
                feed.seticon(cursor.getString( cursor.getColumnIndex("icon")));

                feeds.add(feed);
            }while (cursor.moveToNext());
        }

        return feeds;
    }

    /**
     * DB handler class
     * get next feed it method
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public String getNextId(){
        String selectQuery = "SELECT count(*)+1 as id FROM soccer";
        db = getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        cursor.moveToFirst();
        return cursor.getString(cursor.getColumnIndex("id"));
    }

    /**
     * DB handler class
     * show a toast message
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void ShowToast(String info) {
        Toast toast = Toast.makeText(c, Html.fromHtml("<font color='purple' ><b>" + info + "</b></font>"), Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }
}
