package com.cst2335.groupproject;

import java.util.ArrayList;

/**
 * This class creates a trivia object equivalent to 1 question.
 */
public class TriviaQuestion {

    protected long id;
    protected String question;
    protected String type;
    protected String correctAnswer;
    protected ArrayList<String> incorrectAnswers;
    protected String state;

    /**
     * @param id the position (index) of the question
     * @param question the full question String
     * @param type the type of question (boolean / multiple)
     * @param correctAnswer the correct answer of the question
     * @param incorrectAnswers the incorrect answer(s) (1 for boolean or 3 for multiple)
     */
    public TriviaQuestion(long id, String question, String type, String correctAnswer,
                          ArrayList<String> incorrectAnswers) {
        this.id = id;
        this.question = question;
        this.type = type;
        this.correctAnswer = correctAnswer;
        this.incorrectAnswers = incorrectAnswers;
        state = "unanswered";
    }

    /**
     * @return id; the position (index) of the question
     */
    public long getId() { return id+1; }

    /**
     * @return question; the full question String of the object
     */
    public String getQuestion() { return question; }

    /**
     * @return type; the type of question of the object. Can be either boolean or multiple
     */
    public String getType() { return type; }

    /**
     * @return correctAnswer; The correct answer for the question
     */
    public String getCorrectAnswer() { return correctAnswer; }

    /**
     * @return incorrectAnswers; The 3 incorrect answers for a multiple choice question
     */
    public ArrayList<String> getIncorrectAnswers() { return incorrectAnswers; }

    /**
     * @param state; sets the state of the question (Correct! / Incorrect)
     */
    public void setState(String state) { this.state = state; }

    /**
     * @return state; the state of the question
     */
    public String getState() { return state; }
}
