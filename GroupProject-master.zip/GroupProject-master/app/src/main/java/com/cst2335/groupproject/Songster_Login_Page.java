package com.cst2335.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import com.google.android.material.snackbar.Snackbar;

/**
 * @author sarah Kelly
 * log in page to songster search page
 * there is shared preferences for user to enter their email so its saved when they try to log in next time
 */
public class Songster_Login_Page extends AppCompatActivity {

    // private TextView textView;
    private EditText editText1;
    private EditText editText2;
    private Button button;
    public static final String SHARED_PREFS = "sharedPreferences";
    public static final String TEXT = "Edit Text";
    private String text;

    Switch sw1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songster_login__page);
        sw1=findViewById(R.id.switch1);
        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);

        button = findViewById(R.id.button);

        View someView = findViewById(R.id.mainnn);
        View root = someView.getRootView();
        root.setBackgroundColor(getResources().getColor(android.R.color.background_light));


        /**
         * having the switch button show a snack bar to allow user to change teh background color of the layout between dark and light
         */
        sw1.setOnCheckedChangeListener((cb , checked) -> {
            String t1 = getString(R.string.Songs_sw_on);
            String t2 = getString(R.string.Songs_sw_off);
            String t3 = getString(R.string.Songs_Dark_mode);
            String t4 = getString(R.string.Songs_undo);
            Snackbar snkbar;
            if(checked) {
                snkbar =  Snackbar.make(sw1, t3+" "+t1, Snackbar.LENGTH_LONG).setAction(t4, click -> cb.setChecked(false));
                root.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_dark));
                snkbar.show();
            } else {

                snkbar=Snackbar.make(sw1, t3+ " "+t2, Snackbar.LENGTH_LONG).setAction(t4, click -> cb.setChecked(true));
                root.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                snkbar.show();
            }
        });

        button.setOnClickListener(v -> {

            Intent goToProfile = new Intent(Songster_Login_Page.this, Songster_welcome.class);

            goToProfile.putExtra("EMAIL", editText1.getText().toString());
            startActivity(goToProfile);

        });
        loadSharedPreferences();
        updateViews();


    }

    /**
     * get the shared preferences text and apply it
     */
    @Override
    protected void onPause() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEXT, editText1.getText().toString());
        editor.apply();
        super.onPause();

    }

    /**
     * loading the email from shared preferences
     */
    public void loadSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        text = sharedPreferences.getString(TEXT, "Edit Text");
    }

    /**
     * displaying the email in the email field when starting the app again
     */
    public void updateViews() {
        editText1.setText(text);

    }


}
