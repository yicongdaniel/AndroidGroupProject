package com.cst2335.groupproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

/**
 * @author Mark Newport
 * purpose: This class accepts user input for the type of game they want(count, type, difficulty)
 * that is used to create a String for the URL for the next activity
 * The previous input data is saved and presented once the user revisits this page
 */
public class TriviaLogin extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    /**
     * questionNum is the EditText value of the number of questions
     * difficulty is the Spinner that contains an array of values(easy, medium, hard)
     * trueFalse, multiple are checkboxes for the type of game(boolean, multiple choice, both)
     * submitBtn Button that creates the URL and creates an intent to start the game
     * prefs is sharedPreferences used to store and retrieve previous user input
     */
    private SharedPreferences prefs = null;
    private EditText questionNum;
    private CheckBox trueFalse, multiple;
    private Spinner difficulty;

    /**
     * @param savedInstanceState
     * This method further validates user input to prevent errors in the URL String
     * It uses sharedPreferences to retrieve the previous games input values and sets it back
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia_login);

        /**
         * Getting the widgets on screen by their ids.
         * header is the page header that sets the text to "Welcome back" if the player is returning
         * submitBtn is the button pressed to start an intent to play the game
         */
        questionNum = findViewById(R.id.trivia_number);
        difficulty = findViewById(R.id.difficulty_level);
        trueFalse = findViewById(R.id.boolean_selection);
        multiple = findViewById(R.id.multiple_selection);
        TextView header = findViewById(R.id.trivia_header);
        Button submitBtn = findViewById(R.id.submit_trivia);

        /**
          Using getSharedPreferences (prefs) to retrieve the selection of the last game(onPause)
          Variables savedString, isMultiple, isTrueFalse, diffIndex are used to store the values
          Default values are the values a user playing for the first time
          Accessed using the key used when storing in onPause()
         */
        prefs = getSharedPreferences("number", Context.MODE_PRIVATE);
        String savedString = prefs.getString("QuestionNum", "");
        boolean isMultiple = prefs.getBoolean("Multiple", false);
        boolean isTrueFalse = prefs.getBoolean("TrueFalse", false);
        int diffIndex = prefs.getInt("diffIndex", 0);

        /**
         * We restore the preferences(value of the variables) of the last game played using
         * the variables that stored getSharedPreferences values
         * Using the retrieved index, we set the value of difficulty. multiple & trueFalse are set
         * using the stored boolean. questionNum is also set & used to change the header text
         */
        difficulty.setSelection(diffIndex);
        multiple.setChecked(isMultiple);
        trueFalse.setChecked(isTrueFalse);
        questionNum.setText(savedString);
        if(!savedString.equals("")) {
            header.setText(getResources().getString(R.string.trivia_welcome));
        }

        /**
         * finding the toolbar on screen and calling setSupportActionBar that then
         * calls onCreateOptionsMenu
         */
        Toolbar triviaToolBar = findViewById(R.id.trivia_toolbar);
        setSupportActionBar(triviaToolBar);

        /**
         * finding the drawerLayout and setting the toggle button to it so it becomes visible
         */
        DrawerLayout triviaDrawer = findViewById(R.id.trivia_drawer);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, triviaDrawer, triviaToolBar,
                R.string.open, R.string.close);
        triviaDrawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navView = findViewById(R.id.trivia_nav_view);
        navView.setNavigationItemSelectedListener(this);
        /**
         * displays a toast if both checkboxes are checked indicating a game that is mixed type
         * This is to help clarify to the user that they selected a mixed game
         * 2 click listeners as the last clicked can be either one
         */
        trueFalse.setOnClickListener(e -> {
            if(multiple.isChecked() && trueFalse.isChecked()) {
                Toast.makeText(this, getResources().getString(R.string.trivia_toast_type),
                        Toast.LENGTH_SHORT).show();
            }
        });

        multiple.setOnClickListener(e -> {
            if(trueFalse.isChecked() && multiple.isChecked()) {
                Toast.makeText(this, getResources().getString(R.string.trivia_toast_type),
                        Toast.LENGTH_SHORT).show();
            }
        });

        /**
         * ClickListener for the submit button where entry validation and the url is built
         * It checks that questionNum is less than 50 (parseLong last to be able to compare) or empty
         */
        Intent triviaPage = new Intent(this, TriviaActivity.class);
        submitBtn.setOnClickListener(e -> {
            if(questionNum.getText().toString().isEmpty() || Long.parseLong(questionNum.getText().toString()) > 50) {
                Snackbar.make(submitBtn, getResources().getString(R.string.invalid_count),
                        Snackbar.LENGTH_LONG).setAction("Ok", c ->
                        questionNum.getText().clear()).show();
                return;
            }
            /**
             * At least one checkbox must be checked if not a Snack bar is shown and is returned
             */
            if(!multiple.isChecked() && !trueFalse.isChecked()) {
                Snackbar.make(submitBtn, getResources().getString(R.string.trivia_no_type),
                        Snackbar.LENGTH_LONG).setAction("Ok", c -> {}).show();
                return;
            }

            /**
             * In order to get the value of difficulty we first have to get that index
             * Then we are able to use the index to access the value (cannot be null)
             */
            int diffId = difficulty.getSelectedItemPosition();
            String difficultyValue = String.valueOf(difficulty.getItemAtPosition(diffId));

            /**
             * String builder is used to build the Trivia API URL using the variables
             * Appending using builder is more optimal than concatenation for this (faster)
             */
            StringBuilder builder = new StringBuilder("https://opentdb.com/api.php?amount=");
            builder.append(questionNum.getText().toString()).append("&difficulty=").append(difficultyValue);

            /**
             * We already have the URL for a mixed question type now we look for only one that is
             * checked. If one is then we append the type
             */
            if (!trueFalse.isChecked() || !multiple.isChecked()) {
                if(trueFalse.isChecked()) {
                    builder.append("&type=").append("boolean");
                }
                else if(multiple.isChecked()) {
                    builder.append("&type=").append("multiple");
                }
            }
            triviaPage.putExtra("TriviaUrl", builder.toString());
            triviaPage.putExtra("difficulty", difficultyValue);
            startActivity(triviaPage);
        });
    }

    /**
     * SharedPreferences is used to locally  store the input of the options they just selected.
     * Values of trueFalse, multiple use booleans to store the checked values.
     * Difficulty value is the int index, and String for questionNum
     */
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("QuestionNum", questionNum.getText().toString());
        editor.putInt("diffIndex", difficulty.getSelectedItemPosition());
        editor.putBoolean("TrueFalse", trueFalse.isChecked());
        editor.putBoolean("Multiple", multiple.isChecked());
        editor.apply();
    }

    /**
     * @param item are the selection of other activities that the user can navigate to
     * @return true
     * If the item is selected, an intent is made to go to that activity(other members activities)
     */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {

            case R.id.songster :
                Intent intent = new Intent(this, Songster_Search.class);
                startActivity(intent);
                break;
            case R.id.car :
                Intent carIntent = new Intent(this, CarMain.class);
                startActivity(carIntent);
                break;
            case R.id.soccer :
                Intent soccerIntent = new Intent(this, SoccerFeedsActivity.class);
                startActivity(soccerIntent);
                break;
            case R.id.main_page :
                Intent mainIntent = new Intent(this, MainActivity.class);
                startActivity(mainIntent);
                break;
        }
        return true;
    }

    /**
     * @param menu the toolbar item
     * @return true
     * inflates the help menu item for the toolbar
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.trivia_help_menu, menu);
        return true;
    }

    /**
     * @param item selection of other activities and the help dialog
     * @return true
     * clicking on the item will give the user a dialog of instructions on how to play the game
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch(item.getItemId()) {

            case R.id.trivia_songster :
                Intent intent = new Intent(this, Songster_Search.class);
                startActivity(intent);
                break;
            case R.id.trivia_car :
                Intent carIntent = new Intent(this, CarMain.class);
                startActivity(carIntent);
                break;
            case R.id.trivia_soccer :
                Intent soccerIntent = new Intent(this, SoccerFeedsActivity.class);
                startActivity(soccerIntent);
                break;
            case R.id.trivia_help :
            AlertDialog.Builder helpBuilder = new AlertDialog.Builder(this);
            helpBuilder.setTitle(getString(R.string.trivia_help_title)).setMessage(getString(
                    R.string.trivia_how)).setPositiveButton("ok", (e, arg) -> {
            })
                    .create().show();
        }
        return true;
    }
}