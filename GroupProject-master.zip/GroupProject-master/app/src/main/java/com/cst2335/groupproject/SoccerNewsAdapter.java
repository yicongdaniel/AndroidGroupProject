package com.cst2335.groupproject;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Soccer data adapter
 *
 * @author – Hong Liang
 * @version – 2021.3
 * @param –
 * @return –
 * @since – 1.0
 */
public class SoccerNewsAdapter extends BaseAdapter {

    List<SoccerFeed> feeds = new ArrayList<SoccerFeed>();
    Context context;

    public SoccerNewsAdapter(Context context) {
        this.context = context;

    }

    public SoccerNewsAdapter() {
        this.context = context;

    }

    private static String table_name = "soccer";

    /**
     * add method to add a feed into database
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void add(SoccerFeed feed,int toDB) {
        if (!this.feeds.contains(feed)){
            this.feeds.add(feed);
            if (toDB==1){
                SoccerDBHandler DBH = new SoccerDBHandler(context,"soccerapp",null,1);
                DBH.insertFeed(feed);
            }
            notifyDataSetChanged();
        }
    }

    /**
     * remove method to remove a feed at specified position
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void remove(int position) {
        SoccerDBHandler DBH = new SoccerDBHandler(context,"soccerapp",null,1);
        DBH.deleteFeed((SoccerFeed)getItem(position));
        this.feeds.remove(getItem(position));
        notifyDataSetChanged();
    }

    /**
     * remove all feed method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void removeAll() {
        for (SoccerFeed feed: feeds ){
            feeds.remove(feed);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return feeds.size();
    }

    @Override
    public Object getItem(int position) {
        return feeds.get(position);
    }

    /**
     * getview method to prepare to display on listview
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        NewsViewHolder holder = new NewsViewHolder();
        LayoutInflater messageInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        SoccerFeed feed = feeds.get(position);

        convertView = messageInflater.inflate(R.layout.soccer_feed_item, null);
        holder.feedsBody = (TextView) convertView.findViewById(R.id.soccermessage_body);
        holder.ic= (ImageView) convertView.findViewById(R.id.soccerimageView5);
        convertView.setTag(holder);
        holder.feedsBody.setText(feed.getarticle_date()+"\n"+feed.getTitle());
        holder.ic.setImageBitmap(decodeBase64(feed.geticon()));

     return convertView;
    }

    /**
     * decode method to decode a string to bitmap
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public static Bitmap decodeBase64(String input) {
        byte[] decodedByte = Base64.decode(input, 0);
        return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}

/**
 * view holder method
 *
 * @author – Hong Liang
 * @version – 2021.3
 * @param –
 * @return –
 * @since – 1.0
 */
class NewsViewHolder {
    public View feed_view;
    public ImageView ic;
    public TextView feedsBody;
}
