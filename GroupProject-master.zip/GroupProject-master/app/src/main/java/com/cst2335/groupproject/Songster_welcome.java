package com.cst2335.groupproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

/**
 * @author sarah Kelly
 * this class implements NavigationView which allows to override methods to open the navigation drawer layout as well as the toolbar
 */
public class Songster_welcome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    Button searchSongster;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songster_toolbar_layout);


        //Get toolbar
        Toolbar tBar = findViewById(R.id.toolbar);
        //Load the toolbar


        //For NavigationDrawer:
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
       drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }

    /**
     *
     * @param menu activate the menu created
     * @return boolean onCreateOptionsMenu(menu)
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inf = getMenuInflater();
        inf.inflate(R.menu.example_menu, menu);
        return super.onCreateOptionsMenu(menu);


    }


    /**
     * using switch cases to decide which item is being activated by the user
     * @param item each item has an alert dialog which gets activated when teh user clicks on teh toolbar item
     * @return true if item was clicked
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item2:


                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder.setTitle(R.string.Songs_About);
                //1-Alert dialog using menu item
                alertDialogBuilder.setMessage(String.format(getString(R.string.Songs_info)))

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();

                return true;

            case R.id.item3:


                AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder2.setTitle(R.string.Songs_Con_info);
                //2-Alert dialog using menu item
                alertDialogBuilder2.setMessage(String.format(getString(R.string.Songs_phone)))

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();

                return true;

            default:
                return super.onOptionsItemSelected(item);

        }


    }

    /**
     * when user clicks on one of the items in the navigation menu it will goes to that activity
     * @param item the item selected by the user
     * @return true if item is selected
     */

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {


            switch (item.getItemId()) {

                case R.id.songster:
                    Intent intent = new Intent(this, Songster_Search.class);
                    startActivity(intent);
                    break;
                case R.id.trivia:
                    Intent intent2 = new Intent(Songster_welcome.this, TriviaLogin.class);
                    startActivity(intent2);

                    break;
                case R.id.soccer:
                    Toast.makeText(this, "You clicked on Soccer App", Toast.LENGTH_SHORT).show();

                    break;
                case R.id.car:
                    Intent goToCarDB = new Intent(Songster_welcome.this, CarMain.class);
                    startActivity(goToCarDB);

                    break;
                case R.id.main_page:
                    Intent intent3 = new Intent(this, MainActivity.class);
                    startActivity(intent3);

            }

            return false;
        }

}

