package com.cst2335.groupproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * empty fragment class
 *
 * @author – Hong Liang
 * @version – 2021.3
 * @param –
 * @return –
 * @since – 1.0
 */
public class SoccerEmptyActivity extends AppCompatActivity {

    private SoccerDetailsFragment aFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.soccer_activity_empty);

        Bundle dataToPass = getIntent().getExtras();

        SoccerDetailsFragment dFragment =new SoccerDetailsFragment();
        dFragment.setArguments(dataToPass);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.soccerframelayoutID,dFragment)
                .commit();

    }
}