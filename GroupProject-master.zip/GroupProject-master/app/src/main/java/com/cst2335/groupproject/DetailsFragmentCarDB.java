package com.cst2335.groupproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
/**
 * This class is a fragment of car data base detail
 */
public class DetailsFragmentCarDB extends Fragment {
    private Bundle dataFromActivity;
    private long id;
    public AppCompatActivity parentActivity;
    SQLiteDatabase db;

    /**
     * No-arg constructor
     */
    public DetailsFragmentCarDB() {}
    /**
     * This fragment will show different car information base on what user enter on the list view
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return result
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        dataFromActivity = getArguments();
        id = dataFromActivity.getLong("ID");
//        String ModelID = dataFromActivity.getString("ModelID");
        String ModelName = dataFromActivity.getString("ModelName");
        String CarMake = dataFromActivity.getString("CarMake");
        // Inflate the layout for this fragment
        View result = inflater.inflate(R.layout.fargment_car_db, container, false);
        //show the MODEL id:
        TextView model_id = result.findViewById(R.id.Database_ID);
        model_id.append(" " + id);
        //show the MODEL NAME:
        TextView model_name = result.findViewById(R.id.Model_Name);
        model_name.append(" " + ModelName);
        //show the CAR MAKE:
        TextView make = result.findViewById(R.id.Made_Name);
        make.append(" " + CarMake);
        //initialize database db object
        MyOpenerCar dbOpener = new MyOpenerCar( getActivity());
        db = dbOpener.getWritableDatabase();

        /**
         * View button goes to google search base on model name and car make
         */
        Button viewButton = (Button) result.findViewById(R.id.button_view);
        viewButton.setOnClickListener(clk -> {
            String GoogleURL = "http://www.google.com/search?q=" + ModelName + "+" + CarMake;
            Intent google = new Intent(android.content.Intent.ACTION_VIEW);
            google.setData(Uri.parse(GoogleURL));
            startActivity(google);
        });
        /**
         * Shop button goes to autoTrader website base on model name and car make
         */
        Button shopButton = (Button) result.findViewById(R.id.button_shop);
        shopButton.setOnClickListener(clk -> {
            String autoTraderURL = "https://www.autotrader.ca/cars/?mdl=" + ModelName + "&make=" + CarMake + "&loc=K2G1V8";
            Intent autoTrader = new Intent(android.content.Intent.ACTION_VIEW);
            autoTrader.setData(Uri.parse(autoTraderURL));
            startActivity(autoTrader);
        });
        return result;
    }
    /**
     * //context will either be FragmentExample for a tablet, or EmptyActivity for phone
     * @param context context
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        parentActivity = (AppCompatActivity) context;
    }

}