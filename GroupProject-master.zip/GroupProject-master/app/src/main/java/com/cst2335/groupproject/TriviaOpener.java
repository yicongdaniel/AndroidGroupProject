package com.cst2335.groupproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * @author Mark Newport
 * DATABASE_NAME the name of the high score database
 * VERSION is the current version of the database
 * TABLE_TRIVIA the name of the high score table
 * COL_NAME the players name
 * COL_SCORE the amount of questions answered correctly
 * COL_COUNT the total amount of questions answered
 * COL_TYPE the difficulty played
 * COL_ID the primary key for the highscore row
 */
public class TriviaOpener extends SQLiteOpenHelper {

    protected final static String DATABASE_NAME = "TriviaHighScore";
    protected final static int VERSION = 1;
    public final static String TABLE_TRIVIA = "TRIVIA";
    public final static String COL_NAME = "PLAYER";
    public final static String COL_SCORE = "SCORE";
    public final static String COL_COUNT = "COUNT";
    public final static String COL_TYPE = "TYPE";
    public final static String COL_ID = "_id";

    public TriviaOpener(Context ctx) {
        super(ctx, DATABASE_NAME, null, VERSION);
    }

    /**
     * @param db executes an SQL statement to create the high score database if the database
     * does not exist
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE "+TABLE_TRIVIA+ " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "

                +COL_NAME+ "  text,"
                +COL_SCORE+ " INTEGER,"
                +COL_COUNT+ " INTEGER,"
                +COL_TYPE+ " text)");
    }

    /**
     * @param db SQLLite database
     * @param oldVersion lower version number
     * @param newVersion the new (higher) version number
     * This method gets called if the devices db version is lower than VERSION
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " +TABLE_TRIVIA);
        onCreate(db);
    }
}
