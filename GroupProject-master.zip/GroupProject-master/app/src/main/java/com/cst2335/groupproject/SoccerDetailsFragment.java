package com.cst2335.groupproject;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

/**
 * details fragment class
 *
 * @author – Hong Liang
 * @version – 2021.3
 * @param –
 * @return –
 * @since – 1.0
 */
public class SoccerDetailsFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_PARAM3 = "param3";
    private static final String ARG_PARAM4 = "param4";
    private static final String ARG_PARAM5 = "param5";
    private static final String ARG_PARAM6 = "param6";
    private static final String ARG_PARAM7 = "param7";
    private static final String ARG_PARAM8 = "param8";


    // TODO: Rename and change types of parameters
    private String img;
    private String title;
    private String date;
    private String url;
    private String desc;
    private String imgLink;
    private boolean isToSave;
    private SoccerNewsAdapter favouritesoccerAdapter;
    private CoordinatorLayout coordinatorLayout;
    private String id;

    public SoccerDetailsFragment() {
        // Required empty public constructor

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment DetailsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SoccerDetailsFragment newInstance(String param1, String param2,String param3,String param4,String param5,String param6,boolean param7,String param8) {
        SoccerDetailsFragment fragment = new SoccerDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        args.putString(ARG_PARAM3, param3);
        args.putString(ARG_PARAM4, param4);
        args.putString(ARG_PARAM5, param5);
        args.putString(ARG_PARAM6, param6);
        args.putBoolean(ARG_PARAM7, param7);
        args.putString(ARG_PARAM8, param8);
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * oncreate method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            img = getArguments().getString("icon");
            title = getArguments().getString("title");
            date = getArguments().getString("date");
            url = getArguments().getString("url");
            desc = getArguments().getString("description");
            imgLink= getArguments().getString("imgLink");
            isToSave=getArguments().getBoolean("isToSave");
            id=getArguments().getString("id");

            favouritesoccerAdapter = new SoccerNewsAdapter(this.getContext());
        }

    }

    /**
     * decode method to decode string into bitmap
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public static Bitmap decodeBase64(String input) {
        byte[] decodedByte = Base64.decode(input, 0);
        return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
    }

    /**
     * create view method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –LayoutInflater inflater, ViewGroup container,
     *                              Bundle savedInstanceState
     * @return –
     * @since – 1.0
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        LayoutInflater lf = getActivity().getLayoutInflater();
        View view =  lf.inflate(R.layout.soccer_fragment_details, container, false);

        ImageView icon = (ImageView) view.findViewById(R.id.soccerimageViewDetails);
        icon.setImageBitmap(decodeBase64(img));

        TextView text = (TextView) view.findViewById(R.id.soccertxtDate);
        text.setText("DATE:   "+date);
        TextView txttitle = (TextView) view.findViewById(R.id.soccertxtTitle);
        txttitle.setText("TITLE:   "+title);

        TextView txturl = (TextView) view.findViewById(R.id.soccertxtURL);
        txturl.setText("URL:   "+url);

        TextView txtDesc = (TextView) view.findViewById(R.id.soccertxtDesc);
        txtDesc.setText("DESCRIPTION:   "+desc);


        final Button browse_Button = (Button) view.findViewById(R.id.soccerbutton_browse);

        browse_Button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                goToUrl ( url);
            }
        });

            final Button save_Button = (Button) view.findViewById(R.id.soccerbutton_savetoFavourite);
            if (isToSave==true){
                save_Button.setText(R.string.soccersavetofavourite);
            }else{
                save_Button.setText(R.string.soccerREMOVEFavourite);
            }

        save_Button.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override

            public void onClick(View v) {

                try {

                    if (isToSave==true){
                        savetoFavourite();
                    }else{
                        removeFromFavourite();
                    }


                  } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // Inflate the layout for this fragment
        return view;

    }

    /**
     * go to an url method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    private void goToUrl(String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    /**
     * save to favourite datgabase
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void savetoFavourite(){
        SoccerDBHandler DBH =  new SoccerDBHandler(this.getContext(), "soccerapp", null, 1);
        SoccerFeed feed = new SoccerFeed();
        feed.setId(id);
        feed.setTitle(title);
        feed.setarticle_url(url);
        feed.setimg(imgLink);
        feed.setarticle_desc(desc);
        feed.setarticle_date(date);
        feed.seticon(img);
        DBH.insertFeedToFavourite(feed,0);
    }

    /**
     * remove a feed from favourite table
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void removeFromFavourite(){

        Snackbar snackbar = Snackbar.make( this.getView(), "This article will be removed from your favourite!", Snackbar.LENGTH_SHORT);
        // ADD Action Click Retry Listener
        snackbar.setAction("Undo", new UndoListener());
        // show the Snackbar
        snackbar.show();

        SoccerDBHandler DBH =  new SoccerDBHandler(this.getContext(), "soccerapp", null, 1);
        SoccerFeed feed = new SoccerFeed();
        feed.setId(id);
        feed.setTitle(title);
        feed.setarticle_url(url);
        feed.setimg(imgLink);
        feed.setarticle_desc(desc);
        feed.setarticle_date(date);
        feed.seticon(img);
        DBH.removeFeedFromFavourite(feed);

//        SoccerFeedsActivity fdActivity = new SoccerFeedsActivity();
//        fdActivity.reloadFavourite();

    }

    /**
     * display toast message method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void ShowToast(String info) {
        Toast toast = Toast.makeText(this.getContext(), Html.fromHtml("<font color='purple' ><b>" + info + "</b></font>"), Toast.LENGTH_SHORT);
        //  toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }

    /**
     * toast undo method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    private class UndoListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {

            SoccerDBHandler DBH =  new SoccerDBHandler(getContext(), "soccerapp", null, 1);
            SoccerFeed feed = new SoccerFeed();
            feed.setId(id);
            feed.setTitle(title);
            feed.setarticle_url(url);
            feed.setimg(imgLink);
            feed.setarticle_desc(desc);
            feed.setarticle_date(date);
            feed.seticon(img);
            DBH.insertFeedToFavourite(feed,1);
            ShowToast("The favourite is restored!");

        }
    }

}