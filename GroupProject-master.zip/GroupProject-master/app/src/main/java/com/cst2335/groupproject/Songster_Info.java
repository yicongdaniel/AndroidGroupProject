package com.cst2335.groupproject;

/**
 * this class hold data about the songs such as song_id, title, and artist_id
 *
 */
public class Songster_Info {


    /**
     * a static variable that holds the songs returned from search result
     */
    public final static String TABLE_NAME_SEARCH_RESULT = "SONG_LIST";

    /**
     * a static variable that holds the songs in favorite songs
     */
    public final static String TABLE_NAME_FAVORITE = "SONG_FAV";
    /**
     * a static variable that holds the column name _id
     */
    public final static String COL_ID = "_id";

    /**
     * a static variable that holds the column name Title
     */
    public final static String COL_TITLE = "Title";
    /**
     * a static variable that holds the column name art_Id
     */
    public final static String COL_IDArt = "_artId";





    /**
     * The primary key id in the database
     */
    private long songId;

    /**
     * The title of the song
     */
    private String songTitle;

    /**
     * the artist id
     */
    private int artId;


    /**
     *
     * @return songId
     */
    public long getSongId() {

        return songId;
    }

    /**
     *
     * @param songId setter sets the songId
     */
    public void setSongId(long songId) {

        this.songId = songId;
    }

    /**
     *
     * @return songTitle
     */

    public String getTitle() {

        return songTitle;
    }
    /**
     *
     * @param title setter sets teh songTitle
     */
    public void setTitle(String title) {

        this.songTitle = title;
    }

    /**
     *
     * @param artId setter sets teh artist id
     */
    public void setArtId(int artId) {

        this.artId = artId;
    }

    /**
     *
     * @return artId
     */

    public int getArtId() {

        return artId;
    }


    }

