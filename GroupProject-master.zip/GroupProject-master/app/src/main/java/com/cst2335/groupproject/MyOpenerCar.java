package com.cst2335.groupproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This is a database helper class for the car database
 */
public class MyOpenerCar extends SQLiteOpenHelper {
    public final static String DATABASE_NAME = "car_database";
    public final static String TABLE_NAME = "car_data";
    public final static String COL1 = "_id";
    public final static String COL2= "ModelName";
    public final static String COL3="Make";
    private static final int DATABASE_VERSION = 6;
    public MyOpenerCar(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    /**
     * excute SQL statement in the car database
     * @param db is the datebase object
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
    /*  db.execSQL("CREATE TABLE " + TABLE_NAME
                + " (COL1 INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL2 + " TEXT,"
                + COL3 + " TEXT);");*/

        db.execSQL(String.format("CREATE TABLE %s " +
                "(%s INTEGER PRIMARY KEY AUTOINCREMENT, " +
                " %s text," +" %s text); ", TABLE_NAME, COL1, COL2, COL3));


    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL( "DROP TABLE IF EXISTS " + TABLE_NAME);//Drop the old table
        onCreate(db);//Create the new table
    }
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL( "DROP TABLE IF EXISTS " + TABLE_NAME);//Drop the old table
        onCreate(db);//Create the new table
    }
}
