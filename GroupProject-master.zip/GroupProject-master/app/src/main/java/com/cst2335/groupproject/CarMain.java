package com.cst2335.groupproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
/**
 * This is the main class for car data base. It does search and display the contents on the list view and go the car database activity
 */
public class CarMain extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private SharedPreferences prefs;
    private CarListAdapter carListAdapter;
    private List<CarMainObj> carList = new ArrayList<>();
    ProgressBar progressBar;
    Intent goToDatabase;
    ListView list;
    DetailsFragmentCar dFragment;
   // MyOpenerCar cardb = new MyOpenerCar(this);
    /**
     * Add funtionalities for the two buttons(search and view) and list view for frgment
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_main);
        progressBar = findViewById(R.id.progressBar);
        //share preferences
        prefs = getSharedPreferences("FileName", Context.MODE_PRIVATE);
        String company = prefs.getString("company", "");
        //User input
        EditText carInput = findViewById(R.id.enterCarMake);
        carInput.setText(company);
        //buttons
        Button search = findViewById(R.id.button_search);
        Button viewDB = findViewById(R.id.button_viewDB);
        //car model list view
        list = findViewById(R.id.listView_car);
        list.setAdapter(carListAdapter = new CarListAdapter());
        //This gets the toolbar from the layout:
        Toolbar tBar = findViewById(R.id.toolbar);
        //For NavigationDrawer:
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        /**
         * Add setOnClickListen for Search button
         */
        search.setOnClickListener(click -> {
            Toast.makeText(this, "Loading data", Toast.LENGTH_LONG).show();
            String carIn = carInput.getText().toString();
            AquireData(carIn);
            sharePreference(carIn);
            carListAdapter.notifyDataSetChanged();
            Snackbar.make(search, "Car list loaded", Snackbar.LENGTH_LONG).show();
        });
        /**
         * Add setOnClickListen for View button
         */
        viewDB.setOnClickListener(click -> {
           // Toast.makeText(this, "Go to Car Database", Toast.LENGTH_LONG).show();
            goToDatabase = new Intent(CarMain.this, CarDatabase.class);
            startActivity(goToDatabase);
        });
        /**
         * Click on list view shows more details for the car. Go to fragment if it is a tablet, go to next activity if is a phone
         */
        boolean isTablet = findViewById(R.id.fragmentLocation_car) != null;
        list.setOnItemClickListener((list, item, position, id) -> {
            //Create a bundle to pass data to the new fragment
            Bundle dataToPass = new Bundle();
            CarMainObj car = carList.get(position);
            dataToPass.putLong("ID", car.getId());
            dataToPass.putString("ModelID", car.getModelID());
            dataToPass.putString("ModelName", car.getModelName());
            dataToPass.putString("CarMake", car.getMade());
            if (isTablet) {
                dFragment = new DetailsFragmentCar();
                dFragment.setArguments( dataToPass ); //pass it a bundle for information
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentLocation_car, dFragment)//call replace()
                        .commit();
            }
            else {//isPhone
                Intent nextActivity = new Intent(CarMain.this, EmptyActivityCar.class);
                nextActivity.putExtras(dataToPass);
                startActivity(nextActivity);
            }
        });

    }
    /**
     * Getting user input and pass into this method for execteing the URL using JSON format. Get called by the search listener above
     * @param company is the user input of the EditText
     */
    private void AquireData(String company) {
        carList.clear();
        progressBar.setVisibility(View.VISIBLE);
        CarQuery carQuery = new CarQuery();
        String url = "https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMake/" + company + "?format=JSON";
        carQuery.execute(url);
    }
    /**
     * Store the shared preferences value to save the last query
     * @param textSave the car make to be saved
     */
    private void sharePreference(String textSave) {
        SharedPreferences.Editor edit = prefs.edit();
        edit.putString("company", textSave);
        edit.commit();
    }
    /**
     * Override 4 methods of the BaseAdapter class.
     */
    public class CarListAdapter extends BaseAdapter {
        /**
         * Get the size of the array list carList
         * @return the size of carList
         */
        @Override
        public int getCount() {
            return carList.size();
        }
        /**
         * Get the position of the array list carList
         * @param position
         * @return the postion of the list
         */
        @Override
        public Object getItem(int position) {
            return carList.get(position);
        }
        /**
         * Get the postion id of the list
         * @param position the position of the list
         * @return the id of the position
         */
        @Override
        public long getItemId(int position) {
            return carList.get(position).getId();
        }
        /**
         * Shows the row view on the list view
         * @param position the position of the list
         * @param convertView the View object
         * @param parent the ViewGroup object
         * @return rowview
         */
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CarMainObj car = (CarMainObj) getItem(position);
            LayoutInflater inflater = getLayoutInflater();
            //make a new row
            View rowView = inflater.inflate(R.layout.activity_car_list, parent, false);
            TextView carView = rowView.findViewById(R.id.car_item);
            carView.setText(car.getModelName());//the list view will only show the model name of the car
            return rowView;
        }
    }
    /**
     * This is the inner class of Car_main class. It provides the AsyncTask to retrieve data from an http server
     */
    private class CarQuery extends AsyncTask<String, Integer, String> {
        private List<CarMainObj> carResults = new ArrayList<>();
        /**
         * This method builds the connection of the http server, and converts into Json object to an Json array
         * Finally loop through the Json array and add each elements (Model_ID, Model_name, etc) into carResults array list
         * @param args
         * @return
         */
        @Override
        protected String doInBackground(String... args) {
            try {
                URL url = new URL(args[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream response = urlConnection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(response, "UTF-8"), 8);
                StringBuilder stringBuilder = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null){
                    stringBuilder.append(line + "\n");
                }
                String result = stringBuilder.toString();
                // convert string to JSON
                JSONObject object = new JSONObject(result);
                JSONArray Jarray  = object.getJSONArray("Results");//get the "Results" from the json array

                for (int i = 0; i < Jarray.length(); i++) {
                    JSONObject Jasonobject = Jarray.getJSONObject(i);
                    CarMainObj car = new CarMainObj();
                    car.setModelID(Jasonobject.getString("Model_ID"));
                    car.setModelName(Jasonobject.getString("Model_Name"));
                    car.setMade(Jasonobject.getString("Make_Name"));
                    //for dubug
                    System.out.println(Jasonobject.getString("Model_Name"));
                    carResults.add(car);
                }
//                //For debuging purpose
//                for (Car name: carResults){
//                    System.out.println(name.getModelName());
//                }
                publishProgress(100);
                progressBar.setProgress(100);
            } catch (Exception e) {
                Log.e("Searching car", e.getMessage());
            }
            return "Done";
        }
        /**
         *Setting the progress bar back to invisible and add the results to the carList
         * @param fromDoInBackground
         */
        public void onPostExecute(String fromDoInBackground){
            progressBar.setVisibility(View.INVISIBLE);
            carList.addAll(this.carResults);
            if (carList.size() == 0) {
                Toast.makeText(CarMain.this, "No Results", Toast.LENGTH_LONG).show();
            }
        }
    }
    /**
     * Implementing this method for NavigationView.OnNavigationItemSelectedListener interface
     * @param menu the menu of the menu 2
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_menu2, menu);
        return true;
    }
    /**
     * Implementing this method for NavigationView.OnNavigationItemSelectedListener interface
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {//tool bar
        String message = null;
        switch(item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.item1:
                startActivity(new Intent(CarMain.this, MainActivity.class));
                break;
            case R.id.item2:
                startActivity(new Intent(CarMain.this, TriviaLogin.class));
                break;
            case R.id.item3:
                startActivity(new Intent(CarMain.this, Songster_Login_Page.class));
                break;
            case R.id.item4:
                startActivity(new Intent(CarMain.this, SoccerFeedsActivity.class));
                break;
            case R.id.item5:
                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.setTitle("Help Menu").setMessage(
                        "1. To search a car, enter the name of car manufacturer and click on the SEARCH button\n" +
                                "2. To view the details of a specific car model, click on the corresponding car item on the list view\n" +
                                "3. To view saved cars, click on the GARAGE button\n" +
                                "4. To remove a car in the garage, long click the corresponding car item, and click YES to confirm")
                        .setPositiveButton("OK",(click,arg)->{}).create().show();
                break;
        }
        return true;
    }
    /**
     * This method is needed for the OnNavigationItemSelected interface:
     * @param item the item of the navigation item
     * @return false
     */
    @Override
    public boolean onNavigationItemSelected( MenuItem item) {//darw
        String message = null;
        switch(item.getItemId()) {
            case R.id.go_back_to_main:
                startActivity(new Intent(CarMain.this, MainActivity.class));
                message = "Go to Main";
                break;
            case R.id.other1:
                startActivity(new Intent(CarMain.this, TriviaLogin.class));
                message = "Go to Trivia game";
                break;
            case R.id.other2:
                startActivity(new Intent(CarMain.this, Songster_Login_Page.class));
                message = "Go to Sonster search";
                break;
            case R.id.other3:
                startActivity(new Intent(CarMain.this, SoccerFeedsActivity.class));
                message = "Go to Soccer API";
                break;
        }
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);
        Toast.makeText(this,  message, Toast.LENGTH_LONG).show();
        return false;
    }

}