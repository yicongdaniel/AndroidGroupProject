package com.cst2335.groupproject;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;




import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import android.widget.Toast;

/**
 * @author Sarah Kelly
 * main page that shows buttons and toolbar to navigate to each topic
 */


public class MainActivity extends AppCompatActivity {
    Button songster;
    Button trivia;
    Button soccer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Intent goToCarDB = new Intent(MainActivity.this, CarMain.class);
        Button btn_carDB = findViewById(R.id.carBtn);
        btn_carDB.setOnClickListener(click-> startActivity(goToCarDB));

      
        songster = findViewById(R.id.songBtn);
        trivia = findViewById(R.id.triviaBtn);
        soccer = findViewById(R.id.SoccerBtn);
        /**
         * when user clicks on the songster button it will go to the topic navigation page
         */

        songster.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Songster_Login_Page.class);
            startActivity(intent);
        });

        trivia.setOnClickListener(e -> {
            Intent intent = new Intent(MainActivity.this, TriviaLogin.class);
            startActivity(intent);
        });

        soccer.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SoccerFeedsActivity.class);
            startActivity(intent);
        });

    }

    /**
     * @param menu used to inflate the menu layout created
     * @return boolean returning true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }


    /**
     * @param item: returns the message inside the item depending on which item the user selected.
     *              also if songster is clicked it will for to the songster navigation page
     * @return returns true.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.choice_1:
                Intent intent = new Intent(this, Songster_Login_Page.class);
                startActivity(intent);
                break;
            case R.id.choice_2:
           //     Toast.makeText(this, "You clicked on Soccer App", Toast.LENGTH_SHORT).show();
                Intent goToSoccerFeeds = new Intent(this, SoccerFeedsActivity.class);
                startActivity(goToSoccerFeeds);
                break;
            case R.id.choice_3:
                Intent intentTrivia = new Intent(this, TriviaLogin.class);
                startActivity(intentTrivia);
                break;
            case R.id.choice_4:
                Intent intentCar = new Intent(this, CarMain.class);
                startActivity(intentCar);

                break;
            case R.id.choice_about:
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder.setTitle(R.string.Sonsgter_ab);
                //1-Alert dialog using menu item
                alertDialogBuilder.setMessage(getString(R.string.Songster_choose1))

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();

                return true;


            case R.id.contact:
                AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder2.setTitle(R.string.Songs_Con_info);

                alertDialogBuilder2.setMessage(R.string.Songs_phone)

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();


                return true;
        }
       return true;



    }
}