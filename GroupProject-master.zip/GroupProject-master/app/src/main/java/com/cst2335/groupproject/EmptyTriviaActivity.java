package com.cst2335.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/**
 * Empty activity used to begin the transaction and replace the layout to a fragment for a phone
 */
public class EmptyTriviaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty_trivia);

        Bundle triviaData = getIntent().getExtras();

        TriviaFragment triviaFragment = new TriviaFragment();
        triviaFragment.setArguments(triviaData);
        getSupportFragmentManager()
                .beginTransaction().replace(R.id.question_fragment, triviaFragment).commit();
    }
}