package com.cst2335.groupproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

/**
 * @author Mark Newport
 * purpose: This class stores a players highscore, name, and difficulty in an SQLite database
 * The previously entered name is also stored in shared preferences. It also displays the previous
 * scores with an option to delete them
 */
public class TriviaHighScore extends AppCompatActivity {

    /**
     * list is an ArrayList containing all of the previous HighScore objects
     * prefs is SharedPreferences used to store and retrieve the player name
     * highScoreAdapter custom adapter that implements 4 overridden methods
     * nameEntered is the EditText used to retrieve the player name
     * db is the SQLite database to store and retrieve the high scores
     */
    private final ArrayList<HighScores> list = new ArrayList<>();
    private SharedPreferences prefs = null;
    private ScoresAdapter highScoreAdapter;
    private EditText nameEntered;
    SQLiteDatabase db;

    /**
     * @param savedInstanceState
     * The onCreate method accepts the
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia_high_score);

        /**
         * Getting difficulty, correct, and count Intent from the previous page. Creating a new
         * EditText and setting the hint. getHighScores is a helper method that retrieves the previous
         * high scores
         */
        Intent gaveOver = getIntent();
        String difficulty = gaveOver.getStringExtra("diff");
        int correct = gaveOver.getIntExtra("correct", 0);
        int answered = gaveOver.getIntExtra("answered", 0);

        ListView leaderBoard = findViewById(R.id.high_score_list);
        TextView header = findViewById(R.id.trivia_leader_board);
        Button homeBtn = findViewById(R.id.trivia_score_btn);
        prefs = getSharedPreferences("NAME", Context.MODE_PRIVATE);
        String savedName = prefs.getString("SCORE_NAME", "");

        nameEntered = new EditText(this);
        nameEntered.setHint(getString(R.string.trivia_hint));
        nameEntered.setText(savedName);

        getHighScores();

        /**
         * This AlertDialog shows the player their score and accepts input for their name. Once
         * entered, ContentValues stores the game results and inserts the values into the database.
         * The adapter is notified and a SnackBar is created is all of the questions were correct
         */
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        leaderBoard.setAdapter(highScoreAdapter = new ScoresAdapter());
        builder.setTitle(String.format(getString(R.string.trivia_message), correct, answered))
                .setMessage(getString(R.string.high_score_name))
                .setView(nameEntered).setPositiveButton("Enter", (click, arg) -> {

                    ContentValues thisRow = new ContentValues();
                    thisRow.put(TriviaOpener.COL_NAME, nameEntered.getText().toString());
                    thisRow.put(TriviaOpener.COL_SCORE, correct);
                    thisRow.put(TriviaOpener.COL_TYPE, difficulty);
                    thisRow.put(TriviaOpener.COL_COUNT, answered);
                    db.insert(TriviaOpener.TABLE_TRIVIA, null, thisRow);

                    homeBtn.setVisibility(View.VISIBLE);
                    header.setVisibility(View.VISIBLE);
                    highScoreAdapter.notifyDataSetChanged();

                    if(correct == answered) {
                        Snackbar.make(leaderBoard, getString(R.string.perfect_score),
                                Snackbar.LENGTH_LONG).setAction("Thanks", e -> { }).show();
                    }
                }).setCancelable(false).create().show();

        /**
         * Onclick Listener for the ListView that allows the player to delete previous high scores
         * A toast is made indicating the delete players name
         */
        leaderBoard.setOnItemLongClickListener((lst, item, pos, id) -> {
            HighScores selected = list.get(pos);
            AlertDialog.Builder deleteRow = new AlertDialog.Builder(this);
            deleteRow.setMessage(getString(R.string.delete_score))
                    .setPositiveButton("Delete", (e, arg) -> {
                        deleteScore(selected);
                        list.remove(pos);
                        highScoreAdapter.notifyDataSetChanged();
                        Toast.makeText(this,getString(R.string.high_score_toast,
                                selected.getName()),Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", (e, arg) -> {})
                    .create().show();
            return true;
        });

        /**
         * Button that creates an intent to return back to the Trivia main page
         */
        homeBtn.setOnClickListener(e -> {
            Intent home = new Intent(this, TriviaLogin.class);
            startActivity(home);
        });
    }

    /**
     * This private helper method uses getWritableDatabase to retrieve the stored scores. Columns are
     * Stored as an array and used for the query. The rows are ordered in desc by the correct answers
     * Each row data is pulled using the column index within a loop & added to the ListArray list
     */
    private void getHighScores() {

        TriviaOpener scores = new TriviaOpener(this);
        db = scores.getWritableDatabase();

        String[] cols = {
                TriviaOpener.COL_ID, TriviaOpener.COL_TYPE, TriviaOpener.COL_SCORE, TriviaOpener.COL_COUNT,
                TriviaOpener.COL_NAME
        };
        Cursor results = db.query(TriviaOpener.TABLE_TRIVIA, cols, null,
                null, null, null, TriviaOpener.COL_SCORE + " DESC", null);

        int idIndex = results.getColumnIndex(TriviaOpener.COL_ID);
        int typeIndex = results.getColumnIndex(TriviaOpener.COL_TYPE);
        int scoreIndex = results.getColumnIndex(TriviaOpener.COL_SCORE);
        int countIndex = results.getColumnIndex(TriviaOpener.COL_COUNT);
        int nameIndex = results.getColumnIndex(TriviaOpener.COL_NAME);

        while (results.moveToNext()) {

            long id = results.getLong(idIndex);
            String name = results.getString(nameIndex);
            String type = results.getString(typeIndex);
            long score = results.getLong(scoreIndex);
            long count = results.getLong(countIndex);

            list.add(new HighScores(id, name, type, score, count));
        }
        results.close();
    }

    /**
     * @param score the high score that is to be deleted from the database
     */
    protected void deleteScore(HighScores score) {
        db.delete(TriviaOpener.TABLE_TRIVIA, TriviaOpener.COL_ID + "= ?",
                new String[] {Long.toString(score.getID())});
    }

    /**
     * This Adapter class implements 4 methods (getCount, getItem, getItemId) set to list. It inflates
     * a view for each of the previous high scores that includes their name, score, and difficulty
     */
    public class ScoresAdapter extends BaseAdapter {

        @Override
        public int getCount() { return list.size(); }

        @Override
        public HighScores getItem(int position) { return list.get(position); }

        @Override
        public long getItemId(int position) { return getItem(position).getID(); }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View scoreView = convertView;

            if (scoreView == null) {
                scoreView = inflater.inflate(R.layout.high_score_trivia, parent, false);
            }
            TextView name = scoreView.findViewById(R.id.trivia_player_name);
            TextView type = scoreView.findViewById(R.id.difficulty_level);
            TextView score = scoreView.findViewById(R.id.trivia_score);

            name.setText(String.format(getString(R.string.player_name),position+1, list.get(position).getName()));
            type.setText(String.format(getString(R.string.game_diff),list.get(position).getType()));
            score.setText(String.format(getString(R.string.total_score),list.get(position).getScore(),
                    list.get(position).getCount()));

            return scoreView;
        }
    }

    /**
     * Private inner class(helper) that stores the attributes and getters for the score
     */
    private static class HighScores {

        protected long id;
        protected String name;
        protected String type;
        protected long score;
        protected long count;

        /**
         * @param id score index
         * @param name player name
         * @param type difficulty (easy, medium, hard)
         * @param score amount of questions answered correctly
         * @param count total amount of questions in the game
         */
        private HighScores(long id, String name, String type, long score, long count) {
            this.id = id;
            this.name = name;
            this.type = type;
            this.score = score;
            this.count = count;
        }

        /**
         * These methods are used to return the score's attributes to update the Adapter when
         * inflating
         */
        public long getID() { return id; }

        public String getName() { return name; }

        public String getType() { return type; }

        public long getScore() { return score; }

        public long getCount() { return count; }
    }

    /**
     * SharedPreferences stores the player name so they don't have to enter it again
     */
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor edit = prefs.edit();
        edit.putString("SCORE_NAME", nameEntered.getText().toString());
        edit.apply();
    }
}