package com.cst2335.groupproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Songster_Fav_Page extends AppCompatActivity   {

    /**
     * the data holder of favorite songs
     */
    private List<Songster_Info> songs;

    /**
     * favorite song adapter for list view
     */
   static SongsAdapter songsAdapter;

    /**
     * db used to get/save favorite song
     */
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songster_fav);

        boolean isTablet = findViewById(R.id.fragment_song_detail) != null;

        /**
         * the ListView to show the favorite songs
         */
        ListView lvFavSong = findViewById(R.id.list_fav_song);

        songs = new ArrayList<>();
        songsAdapter = new SongsAdapter();
        lvFavSong.setAdapter(songsAdapter);

        lvFavSong.setOnItemClickListener((parent, view, position, id) -> {
            view.setSelected(true);

            Songster_Info song = songs.get(position);
            // view detail
            Bundle bundle = new Bundle();
            bundle.putBoolean(Songster_Fragment_Details.KEY_IS_TABLET, isTablet);
            bundle.putBoolean(Songster_Fragment_Details.KEY_IS_FAVORITE, true);
            bundle.putLong("ID", songs.get(position).getSongId());
            bundle.putLong("artId", songs.get(position).getArtId());
            bundle.putString("title", songs.get(position).getTitle());

            if (isTablet) {
                Songster_Fragment_Details songDetailFragment = new Songster_Fragment_Details();
                songDetailFragment.setArguments( bundle );
                getSupportFragmentManager()
                        .beginTransaction()
                        /**
                         * Add the fragment in FrameLayout
                         */
                        .replace(R.id.fragment_song_detail, songDetailFragment)
                        /**
                         *  load the fragment. Calls onCreate() in Songster_Fragment_Details
                         */
                        .commit();

            } else {
                Intent intent = new Intent(Songster_Fav_Page.this, Songster_detail_Empty1.class);
                intent.putExtra(Songster_detail_Empty1.SONGS_ATTRIBUTES, bundle);
                startActivity(intent);



            }
        });

        Songster_DB songDB = new Songster_DB(this);
        db = songDB.getWritableDatabase();
        loadFavoriteSong();
        songsAdapter.notifyDataSetChanged();
    }

    /**
     * loads the favorite song result result when the user logs in the app again
     * has all the columns mentioned in the songDB to be displayed
     * while there are results each song is being added to the  fav song array list
     * then Notifiying the attached observers that the underlying data has been changed by calling
     * notifyDataSetChanged()
     */

    protected void loadFavoriteSong() {

        String[] columns = {Songster_Info.COL_ID, Songster_Info.COL_TITLE, Songster_Info.COL_IDArt};
        Cursor results = db.query(false, Songster_Info.TABLE_NAME_FAVORITE, columns,
                null, null, null, null, null, null);

        int titleColIndex = results.getColumnIndex(Songster_Info.COL_TITLE);
        int songColIndex = results.getColumnIndex(Songster_Info.COL_ID);
        int artColIndex = results.getColumnIndex(Songster_Info.COL_IDArt);

        while (results.moveToNext()) {
            Songster_Info song = new Songster_Info();
            song.setTitle(results.getString(titleColIndex));
            song.setSongId(results.getInt(songColIndex));
            song.setArtId(results.getInt(artColIndex));

            songs.add(song);
        }

        songsAdapter.notifyDataSetChanged();
    }

    /**
     * @param menu used to inflate the menu layout created
     * @return boolean returning true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.songster_app_manu, menu);

        return true;
    }
    /**
     * @param item: returns the message inside the item depending on which item the user selected.
     *              also if songster is clicked it will for to the songster navigation page
     * @return returns true.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.choice_1:
                Intent intent = new Intent(this, Songster_Search.class);
                startActivity(intent);
                break;
            case R.id.choice_2:
                Intent intent2 = new Intent(this, Songster_Fav_Page.class);
                startActivity(intent2);
                break;


            case R.id.choice_3:
                Intent intent3 = new Intent(this, Songster_Login_Page.class);
                startActivity(intent3);

                break;
            case R.id.choice_4:
                Intent intent4 = new Intent(this,MainActivity.class);
                startActivity(intent4);

                break;
            case R.id.choice_about:
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder.setTitle(R.string.Songs_navigate);

                alertDialogBuilder.setMessage(getString(R.string.Songster_menu))

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();

                return true;


            case R.id.contact:
                AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder2.setTitle(R.string.Songs_Con_info);

                alertDialogBuilder2.setMessage(R.string.Songs_phone)

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();


                return true;
        }
        return true;


    }
    /**
     * song adapter used by list view for songs display
     */
    protected class SongsAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return songs.size();
        }

        @Override
        public Songster_Info getItem(int position) {
            return songs.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater layoutInflater = getLayoutInflater();
                convertView = layoutInflater.inflate(R.layout.songster_item, parent, false);
            }
            TextView SongTitle = convertView.findViewById(R.id.songName);
            Songster_Info song = getItem(position);
            SongTitle.setText(String.format(Locale.getDefault(), "%d. %s", position + 1, song.getTitle()));

            return convertView;

        }
    }
}

