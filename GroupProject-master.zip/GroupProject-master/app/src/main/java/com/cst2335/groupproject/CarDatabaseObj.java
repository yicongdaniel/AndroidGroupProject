package com.cst2335.groupproject;
/**
 * The Car info will be stored in the DatabaseOBJ_car after the user save the car, it also provides get and set methods
 */
public class CarDatabaseObj {
    private String ModelName, Make;
    private long id;

    /**
     * 3-arg constructor
     * @param ModelName the model of the car
     * @param Make the make of the car
     * @param id the database id of the car
     */
    public CarDatabaseObj(String ModelName, String Make, long id){
        this.ModelName = ModelName;
        this.Make = Make;
        this.id = id;
    }

    /**
     * Getters for 3 variables
     * @return ModelName, Make, id
     */
    public String getModelName() {
        return ModelName;
    }
    public String  getMake() {
        return Make;
    }
    public long getId() {
        return id;
    }

    /**
     * Setters for 3 variables
     * @param ModelName, Make, id
     */
    public void setModelName(String ModelName) {
        this.ModelName = ModelName;
    }
    public void setMake(String Make){
        this.Make = Make;
    }
    public void setId(long id) { this.id = id; }
}
