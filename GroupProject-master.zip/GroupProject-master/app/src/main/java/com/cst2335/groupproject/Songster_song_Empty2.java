package com.cst2335.groupproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;



public class Songster_song_Empty2 extends AppCompatActivity {

    /**
     * progress bar to show when loading image
     */
    public static final String SONGS_ATTRIBUTES = "SONG_DETAIL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songster_empty_song_details);




        Bundle msgDetails = getIntent().getBundleExtra(SONGS_ATTRIBUTES);


        Songster_Fragment_Details songDetailFragment = new Songster_Fragment_Details();
        songDetailFragment.setArguments( msgDetails );
        getSupportFragmentManager()
                .beginTransaction()
                /**
                 * Add the fragment in FrameLayout
                 */
                .replace(R.id.fragment_song_detail, songDetailFragment)
                /**
                 * actually load the fragment. Calls onCreate() in DetailFragment
                 */
                .commit();
    }


}
