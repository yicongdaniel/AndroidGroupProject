 package com.cst2335.groupproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
 /**
  * @Author Sarah Kelly
  * Song_Search class is where the logic for connecting to the url and searching the json url is implemented. the idea is to have the user enter
  * an artist or a band name and search teh json url and display all songs by that artist in a listView
  */
public class Songster_Search extends AppCompatActivity {

    /**
     *Edit text is accepts user input in teh search bar
     */
    EditText userInput;

     /**
      * the button user clicks to start the search
      */
    Button searchButton;

     /**
      * favorite button to go to favorite page
      */
    Button favBtn;

     /**
      * String variable used in shared preferences
      */
    public static final String TEXT = "Edit_Text";

     /**
      * String variable used to save whats in shared preferences
      */
    private String text;

     /**
      * shared preferences variable
      */
    private SharedPreferences sharedPreferences;

     /**
      * progress bar variable to load
      */
    private ProgressBar pb;

     /**
      * boolean variable to use with fragment
      */
    private boolean isTablet;

     /**
      * String variable to store artist Name
      */
    private String artistName;

     /**
      * listView variable to store song lists after loading
      */
    private ListView songListView;

     /**
      * SQLiteDatabase variable to be used with creating/deleting database
      */
    static SQLiteDatabase db;

     /**
      * arrayList variable for storing songs in database
      */
    List<Songster_Info> songs ;


    /**
     * Adapter variable used for the ListView to show songs
     */
    private SongsAdapter songsAdapter;



     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /**
         * the ListView to show the favorite songs
         */




        setContentView(R.layout.songster_search);
        favBtn = findViewById(R.id.favBtn);
        userInput = findViewById(R.id.editText1);
        searchButton = findViewById(R.id.searchButton);

        pb = findViewById(R.id.prog_bar);



         /**
          *
          */
        isTablet = findViewById(R.id.fragment_song_detail) != null;
        songListView = findViewById(R.id.list_song);


        /**
         * shared preferences used to save the user search term so when they log in next time they will see the same search term as before
         */
    sharedPreferences = getSharedPreferences("Songster", MODE_PRIVATE);
        text = sharedPreferences.getString(TEXT, "");


        userInput.setOnEditorActionListener((v, actionId, event) -> {
            findArtist(userInput.getText().toString().trim());
            return true;
        });
        userInput.setText(text);

        songs = new ArrayList<>();
        /**
         * song adapter used by list view for songs display
         */
        songsAdapter = new SongsAdapter();
        /**
         * sets the data behind the songListView
         */
        songListView.setAdapter(songsAdapter);

         songListView.setOnItemClickListener((parent, view, position, id) -> {


             view.setSelected(true);

             Bundle bundle = new Bundle();
             bundle.putBoolean(Songster_Fragment_Details.KEY_IS_TABLET, isTablet);
             bundle.putBoolean(Songster_Fragment_Details.KEY_IS_FAVORITE, false);
             bundle.putLong("ID", songs.get(position).getSongId());
             bundle.putLong("artId", songs.get(position).getArtId());
             bundle.putString("title", songs.get(position).getTitle());
             if (isTablet) {

                 Songster_Fragment_Details songDetailFragment = new Songster_Fragment_Details();
                 songDetailFragment.setArguments(bundle);
                 getSupportFragmentManager()
                         .beginTransaction()
                         /**
                          * Add the fragment in FrameLayout
                          */
                         .replace(R.id.fragment_song_detail,songDetailFragment)

                         /**
                          * actually load the fragment. Calls onCreate() in DetailFragment
                          */
                         .commit();

             } else {
                 Intent intent = new Intent(Songster_Search.this, Songster_detail_Empty1.class);
                 intent.putExtra(Songster_detail_Empty1.SONGS_ATTRIBUTES, bundle);
                 startActivity(intent);
             }
         });



         /**
          * Set a special listener on the editText which is teh user input. to be called when an action is performed on the text view.
          * This will be called when the enter key is pressed
          */


        searchButton.setOnClickListener(v -> {

            findArtist(userInput.getText().toString().trim());


        });
        /**
         *  pressing on favorite button takes the user to favorite song page
         */
        favBtn.setOnClickListener(v -> {

            Intent intent = new Intent(Songster_Search.this, Songster_Fav_Page.class);
            startActivity(intent);

        });

        /**
         * creating a songDB Object which hold all the column details about the table
         */
        Songster_DB songDB = new Songster_DB(this);
        /**
         * Create and/or open a database that will be used for reading and writing
         */
        db = songDB.getWritableDatabase();
        loadSavedSearchResult();

    }


    /**
     * search artist/band name
     *@param artistName the artist name user entered
     * if no name is entered by teh user then an alert dialog will show telling the user that they need to enter a search term
     *
     */
    private void findArtist(String artistName) {
        if (artistName.isEmpty()) {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(R.string.Songs_error);

            alertDialogBuilder.setMessage(getString(R.string.Songs_err_msg))

                    .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                    })

                    .create().show();

            return;


        }

        /**
         *  InputMethodManager is used to hide the keyboard when searching
         */
        InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

        /**
         * applying shared preferences on artist name entered to save it for next time teh user logs in
         */
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEXT, artistName);
        editor.apply();

        /**
         * snack bar will show while searching for the entered artist name showing the artist name and a srting message
         */
        Snackbar snackbar = Snackbar.make(songListView,
                String.format(getString(R.string.Songster_Artist_search)+ artistName),
                Snackbar.LENGTH_LONG);
        snackbar.show();

        /**
         * makes the progress bar visible while searching
         */
        pb.setVisibility(View.VISIBLE);



        /**
         * using url encoder to to properly all the artist name to the url then add that to execute method to get the results from the url
         */
        String songsterUrl=userInput.getText().toString();
        /**
         * creating an object of teh Asynk task class to execute the url on the entered artist name
         */
        QuerySong querySong = new QuerySong();


        String url =songsterUrl;
        try {
            url = URLEncoder.encode(url,"UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        System.out.println("the url is "+ url);
        /**
         * executing the url on the artist name entered
         * note no xxx here makes teh search not show artist not found if no results
         */

        querySong.execute("https://www.songsterr.com/a/ra/songs.json?pattern="+url);

    }

     /**
      * loads the last searched result when the user logs in the app again
      * has all the columns mentioned in the songDB to be displayed
      * while there are results each song is being added to teh song array list
      * then Notifiying the attached observers that the underlying data has been changed by calling
      * notifyDataSetChanged()
      */
     void loadSavedSearchResult() {
        songs.clear();
        String[] columns = {Songster_Info.COL_ID, Songster_Info.COL_TITLE, Songster_Info.COL_IDArt};
        Cursor results = db.query(false, Songster_Info.TABLE_NAME_SEARCH_RESULT, columns,
                null, null, null, null, null, null);

        int titleColIndex = results.getColumnIndex(Songster_Info.COL_TITLE);
        int songColIndex = results.getColumnIndex(Songster_Info.COL_ID);
        int artColIndex = results.getColumnIndex(Songster_Info.COL_IDArt);

        while (results.moveToNext()) {
            Songster_Info song = new Songster_Info();
            song.setTitle(results.getString(titleColIndex));
            song.setSongId(results.getInt(songColIndex));
            song.setArtId(results.getInt(artColIndex));
            songs.add(song);



        }
        results.close();
        songsAdapter.notifyDataSetChanged();
    }

     /**
      *
      * @param song: insert the result into the database
      */
    private void addToSearchResult(Songster_Info song) {
        ContentValues newRowValue = new ContentValues();
        newRowValue.put(Songster_Info.COL_TITLE, song.getTitle());
        newRowValue.put(Songster_Info.COL_ID, song.getSongId());
        newRowValue.put(Songster_Info.COL_IDArt, song.getArtId());



        db.insert(Songster_Info.TABLE_NAME_SEARCH_RESULT, null, newRowValue);
    }

    /**
     * a subclass of AsyncTask to be used to query songs
     * executes the url using the artist/band name entered by the user
     */
    class QuerySong extends AsyncTask<String, Integer, List<Songster_Info>> {

        @Override
        protected List<Songster_Info> doInBackground(String... strings) {
            List<Songster_Info> songList = new ArrayList<>();
            try {
                URL url;
                HttpURLConnection urlConnection;
                InputStream response;
                url = new URL(strings[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                response = urlConnection.getInputStream();

                BufferedReader reader = new BufferedReader(new InputStreamReader(response, StandardCharsets.UTF_8), 8);
                StringBuilder sb = new StringBuilder();

                String line;
                while ((line = reader.readLine()) != null){
                    sb.append(line).append("\n");
                }
                String result = sb.toString();


                Log.i("inside song Q",result);
                /**
                 * clears search result in databse
                 */
                db.delete(Songster_Info.TABLE_NAME_SEARCH_RESULT, null, null);

                JSONArray array = new JSONArray(result);

        for (int i = 0; i < array.length(); i++) {
            JSONObject jsnObj = array.getJSONObject(i);

            String artist = jsnObj.getString("artist");

            Songster_Info song = new Songster_Info();
            song.setTitle(jsnObj.getString("title"));
             song.setSongId(jsnObj.getInt("id"));

           jsnObj = new JSONObject(artist);
            String artId = jsnObj.getString("id");
            System.out.println("Artist Id is :aaa "+artId);

             song.setArtId( jsnObj.getInt("id"));
            System.out.println("artist is is bbb: "+ song.getArtId() );


                        songList.add(song);
                        addToSearchResult(song);

            Log.i("inside song Q2 ", song.getTitle());

                }

            } catch(IOException | JSONException e) {
                Log.e("DSS", e.getMessage());
            }


            return songList;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(List<Songster_Info> songList) {
            super.onPostExecute(songList);

            songs.clear();
            songs.addAll(songList);

            songsAdapter.notifyDataSetChanged();

            pb.setVisibility(View.GONE);
             if (songs.isEmpty()){

                 Snackbar snackbar = Snackbar.make(songListView,
                         String.format(getString(R.string.artistNotFount)),
                         Snackbar.LENGTH_LONG);

                 snackbar.show();


             }

        }
    }


    /**
     * song adapter used by list view for displaying songs
     */
    class SongsAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return songs.size();
        }

        @Override
        public Songster_Info getItem(int position) {
            return songs.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View newView, ViewGroup parent) {
            if (newView == null) {
                LayoutInflater layoutInflater = getLayoutInflater();
                newView = layoutInflater.inflate(R.layout.songster_item, parent, false);
            }
            TextView SongTitle = newView.findViewById(R.id.songName);
            Songster_Info song = getItem(position);
            SongTitle.setText(String.format(Locale.getDefault(), "%d. %s", position + 1, song.getTitle()));
            return newView;
        }


    }


     /**
      * @param menu used to inflate the menu layout created
      * @return boolean returning true
      */
     @Override
     public boolean onCreateOptionsMenu(Menu menu) {
         MenuInflater inflater = getMenuInflater();
         inflater.inflate(R.menu.songster_app_manu, menu);

         return true;
     }

     /**
      * @param item: returns the message inside the item depending on which item the user selected.
      *              also if songster is clicked it will for to the songster navigation page
      * @return returns true.
      */
     @Override
     public boolean onOptionsItemSelected(MenuItem item) {


         switch (item.getItemId()) {
             case R.id.choice_1:
                 Intent intent = new Intent(this, Songster_Search.class);
                 startActivity(intent);
                 break;
             case R.id.choice_2:
                 Intent intent2 = new Intent(this, Songster_Fav_Page.class);
                 startActivity(intent2);
                 break;


             case R.id.choice_3:
                 Intent intent3 = new Intent(this, Songster_Login_Page.class);
                 startActivity(intent3);

                 break;
             case R.id.choice_4:
                 Intent intent4 = new Intent(this,MainActivity.class);
                 startActivity(intent4);

                 break;
             case R.id.choice_about:


                 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                 alertDialogBuilder.setTitle(R.string.Songs_navigate);
                 //1-Alert dialog using menu item
                 alertDialogBuilder.setMessage(getString(R.string.Songster_menu))

                         .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                         })

                         .create().show();

                 return true;


             case R.id.contact:
                 AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                 alertDialogBuilder2.setTitle(R.string.Songs_Con_info);

                 alertDialogBuilder2.setMessage(R.string.Songs_phone)

                         .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                         })

                         .create().show();


                 return true;
         }
         return true;


     }
}

