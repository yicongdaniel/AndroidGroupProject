package com.cst2335.groupproject;

import android.graphics.Bitmap;

/**
 * feed class
 *
 * @author – Hong Liang
 * @version – 2021.3
 * @param –
 * @return –
 * @since – 1.0
 */
public class SoccerFeed {
    private String id;
    private  String title;
    private  String article_date;
    private  String article_url;
    private  String article_desc;
    private  String img;
    private String icon;

    public SoccerFeed(String id, String title, String article_date, String img,String article_url, String article_desc,String icon) {
        this.id = id;
        this.title = title;
        this.article_date = article_date;
        this.img = img;
        this.article_url=article_url;
        this.article_desc=article_desc;
        this.icon =icon;
    }
    public SoccerFeed() {
        this.id = "";
        this.title =  "";
        this.article_date =  "";
        this.img =  "";
        this.article_url= "";
        this.article_desc= "";
        this.icon="";
    }

    public  String getTitle() {
        return title;
    }
    public void setTitle(String txt) {
        this.title = txt;
    }

    public  String getId() {
        return id;
    }
    public void setId(String txt) {
        this.id = txt;
    }

    public  String getarticle_date() {
        return article_date;
    }
    public void setarticle_date(String txt) {
        this.article_date = txt;
    }

    public  String getarticle_url() {
        return article_url;
    }
    public void setarticle_url(String txt) {
        this.article_url = txt;
    }

    public  String getarticle_desc() {
        return article_desc;
    }
    public void setarticle_desc(String txt) {
        this.article_desc = txt;
    }

    public  String getimg() {
        return img;
    }
    public void setimg(String txt) {
        this.img = txt;
    }

    public  String geticon() {
        return icon;
    }
    public void seticon(String icon) {
        this.icon = icon;
    }


}
