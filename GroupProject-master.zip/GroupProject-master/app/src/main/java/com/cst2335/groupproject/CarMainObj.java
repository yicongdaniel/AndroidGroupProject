package com.cst2335.groupproject;

/**
 * The Car info will be stored in the class of Car, it provides get and set methods when loading car info from the car URL
 */
public class CarMainObj {
    private long  id;
    private String ModelID;
    private String Made, ModelName;

    /**
     * No-arg Constructor
     */
    public CarMainObj(){

    }
    /**
     * 4-arg constructor
     * @param ModelName the model name of the car
     * @param Made the make of the car
     * @param id the database id of the car
     */
    public CarMainObj(String ModelName, String Made, long id){
        this.ModelID = ModelID;
        this.ModelName = ModelName;
        this.Made = Made;
        this.id = id;
    }
    /**
     * 4 get methods
     * @return ModelName, Made, ModelID, id
     */
    //Getters
    public String getModelName() {
        return ModelName;
    }
    public String  getMade() {
        return Made;
    }
    public long getId() {
        return id;
    }
    public String getModelID() {
        return ModelID;
    }
    /**
     * 4 Setters
     * @param Made, Model Name, Model ID, id
     */
    public void setMade(String Made){
        this.Made = Made;
    }
    public void setModelID(String ModelID){
        this.ModelID = ModelID;
    }
    public void setModelName(String ModelName) {
        this.ModelName = ModelName;
    }
    public void setId(long id) {
        this.id = id;
    }
}
