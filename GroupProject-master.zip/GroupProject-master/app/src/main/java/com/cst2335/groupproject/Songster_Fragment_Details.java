package com.cst2335.groupproject;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import static android.content.Intent.getIntent;

/**
 * a class that extends fragment. this class gets the song information and displays int in a fragment
 */
public class Songster_Fragment_Details extends Fragment {

    /**
     * AppCompactActivity variable used as a reference to the parent activity
     */
    private AppCompatActivity parentActivity;

    /**
     * bundle variable to be used in on create view to get the arguments needed
     */
    private Bundle data;

    /**
     * long variable representing teh song id
     */
    private long songId1;

    /**
     * long variable representing teh song title
     */

    private long artId1;

    /**
     * String variable representing the song title
     */
    private String message;

    /**
     * static string variable holds Is tablet value
     */
    public static final String KEY_IS_TABLET = "IS_TABLET";

    /**
     * static string variable holds Is favorite value
     */
    public static final String KEY_IS_FAVORITE = "IS_FAV";

    /**
     * boolean variable representing whether the app is viewd on tablet or not
     */
    private boolean isTablet;


    /**
     * boolean variable representing whether the fragment being viewed from teh favorite page or not
     */
    private boolean isFavorite;
    private View storedView;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        parentActivity = (AppCompatActivity) context;
    }

    /**
     * @param inflater:inflates   the fragment details layout
     * @param container:has       children views
     * @param savedInstanceState: a bundle variable
     * @return storedView
     */

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        /**
         *  calling getArgument to retrieve the data
         */
        data = getArguments();

        songId1 = data.getLong("ID");
        isFavorite = data.getBoolean(KEY_IS_FAVORITE);
        isTablet = data.getBoolean(KEY_IS_TABLET);
        artId1 = data.getLong("artId");
        message = data.getString("title");

        /**
         * store inflated view in a variable
         */
        storedView = inflater.inflate(R.layout.songster_fragment__details, container, false);

        TextView songId = storedView.findViewById(R.id.songId);

        songId.setText(getString(R.string.Songster_id) + songId1);
        /**
         * on click listener when clicking on the song id it should go to teh specific song page on songster website
         */
        songId.setOnClickListener(v -> {

            String url = String.valueOf(songId1);
            try {
                url = URLEncoder.encode(url, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            System.out.println(getString(R.string.Songster_id) + songId);
            /**
             * Uri executes the below url on teh specific songId which goes on the internet and displays that song specific page on google
             */
            Uri uri = Uri.parse("http://www.songsterr.com/a/wa/song?id=" + url); // missing 'http://' will cause crashed
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            System.out.println("uri" + uri);
        });
        TextView songTitle = storedView.findViewById(R.id.songTitle);
        songTitle.setText(getString(R.string.Songster_title) + message);
        TextView artId = storedView.findViewById(R.id.artId);

        artId.setText(getString(R.string.Songster_art_id) + artId1);

        /**
         * on click listener when clicking on the artist id it should go to the specific artist page on songster website
         */
        artId.setOnClickListener(v -> {

            String url = String.valueOf(artId1);
            try {
                url = URLEncoder.encode(url, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            System.out.println("Song id: " + artId1);
            /**
             * Uri executes the below url on the specific artistId which goes on the internet and displays that song specific artist page on google
             */
            Uri uri = Uri.parse("http://www.songsterr.com/a/wa/artist?id=" + url); // missing 'http://' will cause crashed
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            System.out.println("uri" + uri);
        });
        Button favBtn = storedView.findViewById(R.id.addRemFav);
        Button hideBtn = storedView.findViewById(R.id.hide);

        /**
         * if is favorite is true then the button text will be remove from favorite otherwise it will be add to favorite
         */
        favBtn.setText(isFavorite ? "Remove Song from favorite " : "Add Song to favorite");
        favBtn.setOnClickListener(clk -> {

            Songster_DB songDB = new Songster_DB(parentActivity);
            SQLiteDatabase db = songDB.getWritableDatabase();
            /**
             * while it is the favorite song page when teh user clicks teh button it will remove the song from the favorite list otherwise
             * it will save the song to list
             */

            if (isFavorite) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(parentActivity);
                alertDialog.setTitle(getString(R.string.Songster_confirm_msg)).setMessage(R.string.Songster_msg
                ).setPositiveButton(R.string.Songster_yes, (click, arg) -> {
                    removeFavoriteSong(db);
                    if (isTablet) {

                        /**
                         *  removes away the detailed fragment if on tablet
                         */
                        parentActivity.getSupportFragmentManager().beginTransaction().remove(this).commit();

                    } else {
                        /**
                         * else its a phone and will go navigate to a new activity page
                         */
                        Intent i = new Intent(parentActivity, Songster_Fav_Page.class);
                        parentActivity.startActivity(i);
                        Toast.makeText(parentActivity, R.string.Songster_remove_success, Toast.LENGTH_SHORT).show();

                    }
                }).setNegativeButton(R.string.Songster_no, (click, arg) -> {
                }).create().show();


            } else {
                saveToFavorite(db);

            }

        });

        hideBtn.setOnClickListener(clk -> {
            /**
             *  create a fragment transaction to remove the fragment
             */
            parentActivity.getSupportFragmentManager().beginTransaction().remove(this).commit();

        });

        return storedView;
    }


    /**
     * @param db SQLiteDatabase variable to execute on teh table row.
     */
    private void removeFavoriteSong(SQLiteDatabase db) {

        int count = db.delete(Songster_Info.TABLE_NAME_FAVORITE, Songster_Info.COL_ID + " = ?", new String[]{String.valueOf(songId1)});
        if (count > 0) {

            Snackbar snackbar = Snackbar.make(this.storedView, R.string.Songster_remove_success, Snackbar.LENGTH_LONG);
            /**
             * refreshes activity to reflect change in database
             */
            getActivity().recreate();

            snackbar.show();

        } else {
            Snackbar snackbar = Snackbar.make(this.storedView, R.string.songster_failed_to_remove, Snackbar.LENGTH_LONG);
            snackbar.show();

        }
    }

    /**
     * @param db db SQLiteDatabase variable to execute on the table row.
     */
    private void saveToFavorite(SQLiteDatabase db) {
        ContentValues newRowValue = new ContentValues();
        newRowValue.put(Songster_Info.COL_TITLE, message);
        newRowValue.put(Songster_Info.COL_ID, songId1);
        newRowValue.put(Songster_Info.COL_IDArt, artId1);

        long newRow = db.insert(Songster_Info.TABLE_NAME_FAVORITE, null, newRowValue);
        Snackbar snackbar;
        if (newRow >= 0) {
            snackbar = Snackbar.make(this.storedView, R.string.Songster_save_success, Snackbar.LENGTH_LONG);
            if (!isTablet) {

                /**
                 * goes to favorite page to show change when on phone
                 */
                Intent intent = new Intent(parentActivity, Songster_Fav_Page.class);
                parentActivity.startActivity(intent);
                Toast.makeText(parentActivity, R.string.Songster_save_success, Toast.LENGTH_SHORT).show();
            }

        } else {
            /**
             * if song already exist in favorite it will show this snack bar message
             */
            snackbar = Snackbar.make(this.storedView, R.string.Songster_failed_to_save, Snackbar.LENGTH_LONG);

        }
        snackbar.show();

    }

}

