package com.cst2335.groupproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * @author Mark Newport
 * purpose: this Activity retrieves trivia questions from a server and populates a ListView with those
 * questions. As the user plays, the state of the question changes and updates the ListView
 */
public class TriviaActivity extends AppCompatActivity {

    /**
     * arrayQuestions ArrayList that holds each trivia question object (type)
     * myAdapter custom Adapter that implements 4 overridden methods
     * myList ListView that displays each question object of arrayQuestions
     * totalAnswered displays the amount of questions answered
     * answered amount of questions answered; correct amount of questions answered correct
     * progressBar used to show the progress of doInBackground of Async task and is then is hidden
     * difficulty is user selected difficulty (easy, medium, hard)
     * isTablet boolean that returns true if tablet view is found
     */
    private final ArrayList<TriviaQuestion> arrayQuestions = new ArrayList<>();
    private MyTriviaAdapter myAdapter;
    private ListView myList;
    private TextView totalAnswered;
    private int answered, correct;
    private ProgressBar progressBar;
    private String difficulty;
    private boolean isTablet;

    /**
     * @param savedInstanceState
     * This method holds the onItem & onItemLong click listeners as well as sets the list view
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /**
         * Getting the widgets onscreen by their ids
         */
        setContentView(R.layout.activity_trivia);
        totalAnswered = findViewById(R.id.trivia_correct);
        progressBar = findViewById(R.id.trivia_progress_bar);
        progressBar.setVisibility(View.VISIBLE);
        myList = findViewById(R.id.trivia_question_list);
        isTablet = findViewById(R.id.question_fragment) != null;

        /**
         * Getting the URL intent from the previous class and calling execute on ASyncTask to start
         * the thread in doInBackground
         */
        Intent fromLogin = getIntent();
        String url = fromLogin.getStringExtra("TriviaUrl");
        difficulty = fromLogin.getStringExtra("difficulty");

        TriviaQuery triviaQuery = new TriviaQuery();
        triviaQuery.execute(url);
        myList.setAdapter(myAdapter);

        /**
         * If the question hasn't been answered a new Bundle is created and stores
         */
        myList.setOnItemClickListener((list, item, position, id) -> {
            if(arrayQuestions.get(position).getState().equals("unanswered")) {

                Bundle triviaData = new Bundle();
                triviaData.putInt("POSITION", position);
                triviaData.putString("QUESTION", arrayQuestions.get(position).getQuestion());
                triviaData.putString("TYPE", arrayQuestions.get(position).getType());
                triviaData.putStringArrayList("INCORRECT", arrayQuestions.get(position).getIncorrectAnswers());
                triviaData.putString("CORRECT", arrayQuestions.get(position).getCorrectAnswer());
                triviaData.putBoolean("TABLET", isTablet);

                /**
                 * If the user is on a tablet, getSupportFragmentManager(AppCompatAct.) starts a new
                 * transaction to replace the current view with the fragment
                 */
                if (isTablet) {
                    TriviaFragment triviaFragment = new TriviaFragment();
                    triviaFragment.setArguments(triviaData);
                    getSupportFragmentManager()
                            .beginTransaction().replace(R.id.question_fragment, triviaFragment).commit();
                }
                /**
                 * If the user is on a phone, a new intent is created to go to the EmptyTriviaActivity
                 * class. The bundle is passed as an Extra with the intent. StartActivityForResult
                 * because we are looking to retrieve the new state and the index of the question
                 */
                else {
                    Intent nextActivity = new Intent(TriviaActivity.this, EmptyTriviaActivity.class);
                    nextActivity.putExtras(triviaData);
                    startActivityForResult(nextActivity, 1);
                }
            }
        });
        /**
         * If the question has been answered, an AlertDialog shows the user the question, type, and correct answer
         */
        myList.setOnItemLongClickListener((list, item, position, id) -> {

            TriviaQuestion selectedQuestion = arrayQuestions.get(position);
            int title = selectedQuestion.getType().equals("boolean") ? R.string.true_false : R.string.trivia_multiple_choice;
            if(!selectedQuestion.getState().equals("unanswered")) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);

                alertDialog.setTitle(title)
                        .setMessage(selectedQuestion.getQuestion()+"\n"+"Correct Answer: "+
                                selectedQuestion.getCorrectAnswer())
                        .setPositiveButton("Ok", (clk, arg) -> {}).create().show();
            }
            return true;
        });
    }

    /**
     * @param state The String representation of the state of the question object
     * @param pos the index of the question object
     * This method sets objects state using the index. Adds 1 to answered counter and shows a Toast
     * if the question was answered wrong/right. Calls notifyDataSetChanged to update the ListView
     */
    public void getResults(String state, int pos) {
        totalAnswered = findViewById(R.id.trivia_correct);
        arrayQuestions.get(pos).setState(state);
        answered += 1;
        if(state.equals("Correct!")){
            Toast.makeText(this, getResources().getString(R.string.toast_correct), Toast.LENGTH_SHORT).show();
            correct += 1;
        }
        else {
            Toast.makeText(this, getResources().getString(R.string.toast_wrong), Toast.LENGTH_SHORT).show();
        }
        /**
         * When all of the questions have been answered a new intent is made to go to the High Score
         * page. The difficulty, correct answer count & total questions are passed as extras
         */
        if(answered == arrayQuestions.size()) {
            Intent highScore = new Intent(this, TriviaHighScore.class);
            highScore.putExtra("diff", difficulty);
            highScore.putExtra("correct", correct);
            highScore.putExtra("answered", answered);
            startActivity(highScore);
        }
        totalAnswered.setText(String.format(getString(R.string.trivia_counter),answered));
        myAdapter.notifyDataSetChanged();
    }

    /**
     * @param requestCode passed in the onItemClick for the phone view (1)
     * @param resultCode passed in the TriviaFragment (1)
     * @param data the state and index of the object
     * This gets called once the question has been answered in the fragment. Only for a phone
     * It gets the Extras passed in the intent and then delegates updating to the getResults method
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == 1) {
            String update = data.getStringExtra("RESULTS");
            int pos = data.getIntExtra("REMOVE_POSITION", 0);
                getResults(update, pos);
        }
    }

    /**
     * Adapter class that implements 4 Overridden methods. This returns the inflated View
     * for myList at the right position indicating 1 trivia question
     */
    public class MyTriviaAdapter extends BaseAdapter {

        @Override
        public int getCount() { return arrayQuestions.size(); }

        @Override
        public TriviaQuestion getItem(int position) { return arrayQuestions.get(position); }

        @Override
        public long getItemId(int position) { return getItem(position).getId(); }

        /**
         * @param position of the question
         * @param convertView the old view that we reuse (View Holder Pattern)
         * @param parent that this view will be attached to
         * @return the updated & inflated view at the position
         * The views will contain the question, state (color) for each row. The question is displayed
         * if the state is unanswered.
         */
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View questionView = convertView;

            if(questionView == null) {
                questionView = inflater.inflate(R.layout.trivia_list_layout, parent, false);
            }
            TextView state = questionView.findViewById(R.id.question_state);
            TextView triviaNumber = questionView.findViewById(R.id.trivia_position);
            TextView question = questionView.findViewById(R.id.question_list);

            triviaNumber.setText(String.valueOf(position+1));
            state.setText(arrayQuestions.get(position).getState());
            question.setText(null);

            if(arrayQuestions.get(position).getState().equals("unanswered")) {
                question.setText(arrayQuestions.get(position).getQuestion());
                state.setTextColor(getColor(R.color.trivia_unanswered));
            }
            if(arrayQuestions.get(position).getState().equals("Correct!")) {
                state.setTextColor(getColor(R.color.trivia_correct));
            }
            if(arrayQuestions.get(position).getState().equals("Incorrect")) {
                state.setTextColor(getColor(R.color.trivia_wrong));
            }
            return questionView;
        }
    }

    /**
     * This private class establishes a connection to Open Trivia DB to retrieve our question objects
     * queryQuestion the stored trivia question String
     * type is the type of question (boolean or multiple)
     * answer is the correct answer to the question for both types of questions
     * progress is used to update publishProgress within the json loop
     */
    private class TriviaQuery extends AsyncTask<String, Integer, String> {

        String queryQuestion, type, answer, difficulty;
        int progress = 50;
        /**
         * @param args the URL that was passed in execute
         * @return null
         * Runs on the doInBackground thread to prevent network thread exceptions
         */
        @Override
        protected String doInBackground(String... args) {

            /**
             * url object created from the parameters passed to it & establishes a url connection.
             * The response is the text returned back. BufferedReader & StringBuilder both read and
             * build the entire response String. publishProgress values updated to 25 & 50
             */
            try{
                URL url = new URL(args[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream response = urlConnection.getInputStream();
                publishProgress(25);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response,
                        "UTF-8"), 8);
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                publishProgress(50);

                /**
                 * A JSON Object is created from the StringBuilder and a JSON Array is created from
                 * that as each result(questions) is stored as an array.
                 */
                String resultString = stringBuilder.toString();
                JSONObject jResults = new JSONObject(resultString);
                JSONArray questions = jResults.getJSONArray("results");

                /**
                 * the results are iterated over using a JSON object at the current index and
                 * each String(type, question, answer) is stored in the corresponding local variable
                 * Using fromHtml because the API uses html encoding
                 */
                for(int i = 0; i < questions.length(); i++) {
                    JSONObject anObject = questions.getJSONObject(i);
                    queryQuestion = Html.fromHtml(anObject.getString("question")).toString();

                    type = anObject.getString("type");
                    answer = Html.fromHtml(anObject.getString("correct_answer")).toString();
                    JSONArray incorrect = anObject.getJSONArray("incorrect_answers");

                    /**
                     * The incorrect answers are also stored as an array(of 3) so again we iterate over
                     * them to retrieve each one. They are stored as an ArrayList
                     */
                    ArrayList<String> inAnswer = new ArrayList<>();
                    for(int j = 0; j < incorrect.length(); j++) {
                        inAnswer.add(Html.fromHtml(incorrect.getString(j)).toString());
                    }

                    /**
                     * A new TriviaQuestions object is created using the retrieve data as parameters
                     * this new object is then added to arrayQuestions(ArrayList). PublishProgress
                     * is updated in a loop so the average count gets appended and used to update
                     */
                    TriviaQuestion tq = new TriviaQuestion(i, queryQuestion, type, answer, inAnswer);
                    arrayQuestions.add(tq);
                    progress += 50/ questions.length();
                    publishProgress(progress);
                }
                publishProgress(100);
            }
            catch(Exception e) {e.printStackTrace();}
            return null;
        }

        /**
         * @param value for publishProgress that updates the progress bar. Runs on the GUI thread
         */
        @Override
        protected void onProgressUpdate(Integer... value) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(value[0]);
        }

        /**
         * @param s
         * The myList calls setAdapter to update and fill the rows with the questions queried
         * The progress bar is set to invisible as the doInBackground thread is now complete
         */
        @Override
        protected void onPostExecute(String s) {
            myList = findViewById(R.id.trivia_question_list);
            myList.setAdapter(myAdapter = new MyTriviaAdapter());
            myAdapter.notifyDataSetChanged();
            progressBar.setVisibility(View.INVISIBLE);
            totalAnswered.setVisibility(View.VISIBLE);
        }
    }
}