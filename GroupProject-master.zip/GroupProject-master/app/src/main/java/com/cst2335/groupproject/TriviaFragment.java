package com.cst2335.groupproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

/**
 * @author Mark Newport
 * purpose: Fragment class that returns a view (boolean/multiple) to the parent. This allows different
 * Views for a mobile or tablet user
 */
public class TriviaFragment extends Fragment {

    /**
     * state is the state of the question passed in the Bundle
     * correct is the correct answer to the question for both boolean and multiple choice
     * isTablet is true if the user is on a tablet (FrameLayout isn't null)
     * incorrect is an ArrayList containing the wrong answer(s)
     * position is the current question number
     * result is the returned view (either boolean or multiple)
     */
    private String state, correct;
    private boolean isTablet;
    private ArrayList<String> incorrect;
    private int position;
    private View result;
    private AppCompatActivity parentActivity;

    /**
     * @param inflater annotation stating to the compiler a view cannot be returned null
     * @return the View; either boolean or multiple
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        /**
         * Retrieving the data from the Bundle that was passed. Including the position, question,
         * type, correct, and incorrect information of the TriviaQuestion
         */
        Bundle triviaData = getArguments();
        position = triviaData.getInt("POSITION");
        String question = triviaData.getString("QUESTION");
        String type = triviaData.getString("TYPE");
        incorrect = triviaData.getStringArrayList("INCORRECT");
        correct = triviaData.getString("CORRECT");
        isTablet = triviaData.getBoolean("TABLET");

        /**
         * if the question type is boolean we inflate the view and find the widgets for it including:
         * countBool: shows the question number, questionBool: the question, and the 2 true/false buttons
         */
        if(type.equals("boolean")) {
            result = inflater.inflate(R.layout.fragment_trivia_boolean, container, false);
            TextView countBool = result.findViewById(R.id.trivia_fragment_count);
            TextView questionBool = result.findViewById(R.id.trivia_fragment_question);
            Button trueBtn = result.findViewById(R.id.frag_true_btn);
            Button falseBtn = result.findViewById(R.id.frag_false_btn);
            countBool.append(String.valueOf(position+1));
            questionBool.setText(question);

            /**
             * Each button has an on click listener that sets the state if the correct(answer) equals
             * true or false. onReturn method is then called to return the state & position back to
             * the parent activity
             */
            trueBtn.setOnClickListener(e -> {
                state = correct.equals("True") ? "Correct!" : "Incorrect";
                onReturn();
            });
            falseBtn.setOnClickListener(e -> {
                state = correct.equals("False") ? "Correct!" : "Incorrect";
                onReturn();
            });
        }
        /**
         * If the type is "multiple", the multiple choice layout is inflated and returned. We find the
         * 4 button views by id (a,b,c,d) and set the text of countMulti (for the question number) &
         * questionMulti (the multiple choice question)
         */
        else if(type.equals("multiple")) {
            result = inflater.inflate(R.layout.fragment_trivia_multiple, container, false);
            Button aBtn = result.findViewById(R.id.frag_a_btn);
            Button bBtn = result.findViewById(R.id.frag_b_btn);
            Button cBtn = result.findViewById(R.id.frag_c_btn);
            Button dBtn = result.findViewById(R.id.frag_d_btn);

            TextView countMulti = result.findViewById(R.id.trivia_fragment_count1);
            TextView questionMulti = result.findViewById(R.id.trivia_fragment_question1);

            /**
             * optionA, optionB, optionC, optionD are the TextViews that show the different choices
             */
            TextView optionA = result.findViewById(R.id.trivia_multiple_one);
            TextView optionB = result.findViewById(R.id.trivia_multiple_two);
            TextView optionC = result.findViewById(R.id.trivia_multiple_three);
            TextView optionD = result.findViewById(R.id.trivia_multiple_four);

            countMulti.append(String.valueOf(position+1));
            questionMulti.setText(question);

            /**
             * The incorrect answers are in an ArrayList and separate from the correct answer. We
             * add the correct answer to the incorrect list and then call shuffle to randomize the
             * positions. This prevents the correct answer from always being at the same button.
             * We then set the text for each option at the corresponding index
             */
            if(!incorrect.contains(correct)) {
                incorrect.add(correct);
                Collections.shuffle(incorrect);
            }
            optionA.setText(String.format("A: %s",incorrect.get(0)));
            optionB.setText(String.format("B: %s",incorrect.get(1)));
            optionC.setText(String.format("C: %s",incorrect.get(2)));
            optionD.setText(String.format("D: %s",incorrect.get(3)));

            /**
             * Similar to boolean, an onclick listener is attached to each button that looks for
             * if correct is equal incorrect at the index of it (correct answer was added) the state
             * is "Correct!" otherwise it is "Incorrect". onReturn is called for each listener
             */
            aBtn.setOnClickListener(e -> {
                state = correct.equals(incorrect.get(0)) ? "Correct!" : "Incorrect";
                onReturn();
            });
            bBtn.setOnClickListener(e -> {
                state = correct.equals(incorrect.get(1)) ? "Correct!" : "Incorrect";
                onReturn();
            });
            cBtn.setOnClickListener(e -> {
                state = correct.equals(incorrect.get(2)) ? "Correct!" : "Incorrect";
                onReturn();
            });
            dBtn.setOnClickListener(e -> {
                state = correct.equals(incorrect.get(3)) ? "Correct!" : "Incorrect";
                onReturn();
            });
        }
        return result;
    }

    /**
     * This method returns the results(state & position) back to the parent activity. If the user is
     * using a tablet, we create an object of TriviaActivity(casting) and use the Objects utility method
     * to assert it is not null(to be safe) then we call getResults in the parent activity and pass the
     * state & position to update the ListView. Finally getSupportFragmentManager removes this fragment
     */
    private void onReturn(){
        if(isTablet) {
            TriviaActivity triviaActivity = ((TriviaActivity) getActivity());
            Objects.requireNonNull(triviaActivity);
            triviaActivity.getResults(state, position);
            parentActivity.getSupportFragmentManager().beginTransaction()
                    .remove(this).commit();

            /**
             * If the user is on a phone, we create a new intent and put the state and position as
             * extras. We set the results(with result code 1) and call finish. We cannot cast as the
             * parent activity is the Empty activity, so we return the results to onActivityResults
             */
        } else {
            Intent in = new Intent();
            in.putExtra("REMOVE_POSITION", position);
            in.putExtra("RESULTS", state);
            parentActivity.setResult(1, in);
            parentActivity.finish();
        }
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        parentActivity = (AppCompatActivity) context;
    }
}