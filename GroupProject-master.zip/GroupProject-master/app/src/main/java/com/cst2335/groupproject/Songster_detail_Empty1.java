package com.cst2335.groupproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class Songster_detail_Empty1 extends AppCompatActivity {

    /**
     *
     */
    public static final String SONGS_ATTRIBUTES = "SONGS_ATTRIBUTES";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.songster_empty_song_details);



        /**
         * bundle variable that gets the data that was passed
         */
    Bundle msgInfo = getIntent().getBundleExtra(SONGS_ATTRIBUTES);

        /**
         * creating a new fragment details object
         */
    Songster_Fragment_Details songDetailFragment = new Songster_Fragment_Details();
        /**
         * sets the arguments on teh detail fragment object
         */
        songDetailFragment.setArguments( msgInfo );
    getSupportFragmentManager()
                .beginTransaction()
            /**
             * Add the fragment in FrameLayout
             */
                .replace(R.id.fragment_song_detail, songDetailFragment)
            /**
             * load the fragment. Calls onCreate() in DetailFragment
             */
                .commit();
}

    /**
     * @param menu used to inflate the menu layout created
     * @return boolean returning true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.songster_app_manu, menu);

        return true;
    }
    /**
     * @param item: returns the message inside the item depending on which item the user selected.
     *              also if songster is clicked it will for to the songster navigation page
     * @return returns true.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.choice_1:
                Intent intent = new Intent(this, Songster_Search.class);
                startActivity(intent);
                break;
            case R.id.choice_2:
                Intent intent2 = new Intent(this, Songster_Fav_Page.class);
                startActivity(intent2);
                break;


            case R.id.choice_3:
                Intent intent3 = new Intent(this, Songster_Login_Page.class);
                startActivity(intent3);

                break;
            case R.id.choice_4:
                Intent intent4 = new Intent(this,MainActivity.class);
                startActivity(intent4);

                break;
            case R.id.choice_about:
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder.setTitle(R.string.Songs_navigate);
                //1-Alert dialog using menu item
                alertDialogBuilder.setMessage(getString(R.string.Songster_menu))

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();

                return true;


            case R.id.contact:
                AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);// makes alert Dialog full screen
                alertDialogBuilder2.setTitle(R.string.Songs_Con_info);

                alertDialogBuilder2.setMessage(R.string.Songs_phone)

                        .setPositiveButton(R.string.Songs_ok, (click, arg) -> {

                        })

                        .create().show();


                return true;
        }
        return true;


    }
}
