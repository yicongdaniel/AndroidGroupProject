package com.cst2335.groupproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
/**
 * This is the empty activity for fragment_car_db
 */
public class EmptyActivityCarDB extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_car_empty);
        Bundle dataToPass = getIntent().getExtras();
        DetailsFragmentCarDB dFragment  = new DetailsFragmentCarDB();
        dFragment.setArguments( dataToPass ); //pass data to the the fragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentLocation_car, dFragment )
                .commit();//Replace by the fragment layout when user hit the message
    }
}
