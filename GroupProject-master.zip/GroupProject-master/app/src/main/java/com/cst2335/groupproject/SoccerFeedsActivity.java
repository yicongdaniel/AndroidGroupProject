package com.cst2335.groupproject;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;


/**
 * Maib class for the soccerfeeds activity
 *
 * @author – Hong Liang
 * @version – 2021.3
 * @param –
 * @return –
 * @since – 1.0
 */
public class SoccerFeedsActivity extends AppCompatActivity {

    private SoccerNewsAdapter soccerAdapter;
    private SoccerNewsAdapter favouritesoccerAdapter;
    private SoccerNewsAdapter searchsoccerAdapter;
    private SoccerNewsAdapter searchAdapter;
    private ListView soccerFeedsView;
    private ListView favouriteView;
    private ListView searchView;
    private AlertDialog.Builder builder;
    private SoccerDBHandler DBH;
    private SoccerDetailsFragment newFragment;
    private boolean isPhone;
    private  List<SoccerFeed> mList1;
    private List<SoccerFeed> mList;
    private Context c;
    private ProgressBar pb;
    private ViewGroup root;
    private boolean isLoaded;
    private boolean isToSave;
    private SharedPreferences preferences;
    private int soccerRating = 1;

    /**
     * onCreate method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.soccerfeeds_activity);
        c= this.getApplicationContext();



        Dialog alert = new Dialog(SoccerFeedsActivity.this);
        String PREF_FILE_NAME = "SoccerRating";
         preferences = getSharedPreferences(PREF_FILE_NAME, MODE_PRIVATE);
        int storedPreference = preferences.getInt("storedRating", 0);

        LayoutInflater lf = this.getLayoutInflater();
        alert.setContentView(lf.inflate(R.layout.soccer_rating, null));

        ImageButton bt1 = (ImageButton)alert.findViewById(R.id.SoccerimageButton1);
        ImageButton bt2 = (ImageButton)alert.findViewById(R.id.SoccerimageButton2);
        ImageButton bt3 = (ImageButton)alert.findViewById(R.id.SoccerimageButton3);
        ImageButton bt4 = (ImageButton)alert.findViewById(R.id.SoccerimageButton4);
        ImageButton bt5 = (ImageButton)alert.findViewById(R.id.SoccerimageButton5);
        Button btOK = (Button)alert.findViewById(R.id.soccer_rating_ok);

        if (storedPreference==1){
            bt1.setImageResource (R.drawable.soccer_rate_full);
            bt2.setImageResource (R.drawable.soccer_rate_empty);
            bt3.setImageResource (R.drawable.soccer_rate_empty);
            bt4.setImageResource (R.drawable.soccer_rate_empty);
            bt5.setImageResource (R.drawable.soccer_rate_empty);
        }else if (storedPreference==2){
            bt1.setImageResource (R.drawable.soccer_rate_full);
            bt2.setImageResource (R.drawable.soccer_rate_full);
            bt3.setImageResource (R.drawable.soccer_rate_empty);
            bt4.setImageResource (R.drawable.soccer_rate_empty);
            bt5.setImageResource (R.drawable.soccer_rate_empty);
        }else if (storedPreference==3){
            bt1.setImageResource (R.drawable.soccer_rate_full);
            bt2.setImageResource (R.drawable.soccer_rate_full);
            bt3.setImageResource (R.drawable.soccer_rate_full);
            bt4.setImageResource (R.drawable.soccer_rate_empty);
            bt5.setImageResource (R.drawable.soccer_rate_empty);
        }else if (storedPreference==4){
            bt1.setImageResource (R.drawable.soccer_rate_full);
            bt2.setImageResource (R.drawable.soccer_rate_full);
            bt3.setImageResource (R.drawable.soccer_rate_full);
            bt4.setImageResource (R.drawable.soccer_rate_full);
            bt5.setImageResource (R.drawable.soccer_rate_empty);
        }else if (storedPreference==5){
            bt1.setImageResource (R.drawable.soccer_rate_full);
            bt2.setImageResource (R.drawable.soccer_rate_full);
            bt3.setImageResource (R.drawable.soccer_rate_full);
            bt4.setImageResource (R.drawable.soccer_rate_full);
            bt5.setImageResource (R.drawable.soccer_rate_full);
        }

        alert.show();

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bt1.setImageResource (R.drawable.soccer_rate_full);
                bt2.setImageResource (R.drawable.soccer_rate_empty);
                bt3.setImageResource (R.drawable.soccer_rate_empty);
                bt4.setImageResource (R.drawable.soccer_rate_empty);
                bt5.setImageResource (R.drawable.soccer_rate_empty);
                soccerRating = 1;
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bt1.setImageResource (R.drawable.soccer_rate_full);
                bt2.setImageResource (R.drawable.soccer_rate_full);
                bt3.setImageResource (R.drawable.soccer_rate_empty);
                bt4.setImageResource (R.drawable.soccer_rate_empty);
                bt5.setImageResource (R.drawable.soccer_rate_empty);
                soccerRating = 2;
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bt1.setImageResource (R.drawable.soccer_rate_full);
                bt2.setImageResource (R.drawable.soccer_rate_full);
                bt3.setImageResource (R.drawable.soccer_rate_full);
                bt4.setImageResource (R.drawable.soccer_rate_empty);
                bt5.setImageResource (R.drawable.soccer_rate_empty);
                 soccerRating = 3;
            }
        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bt1.setImageResource (R.drawable.soccer_rate_full);
                bt2.setImageResource (R.drawable.soccer_rate_full);
                bt3.setImageResource (R.drawable.soccer_rate_full);
                bt4.setImageResource (R.drawable.soccer_rate_full);
                bt5.setImageResource (R.drawable.soccer_rate_empty);
                 soccerRating = 4;
            }
        });

        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bt1.setImageResource (R.drawable.soccer_rate_full);
                bt2.setImageResource (R.drawable.soccer_rate_full);
                bt3.setImageResource (R.drawable.soccer_rate_full);
                bt4.setImageResource (R.drawable.soccer_rate_full);
                bt5.setImageResource (R.drawable.soccer_rate_full);
                 soccerRating = 5;
            }
        });
        btOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = preferences.edit();
                editor.putInt("storedRating", soccerRating); // value to store
                editor.commit();
                alert.dismiss();
            }
        });

        isToSave=true; // to check if clicked favourite button or all button
        isPhone = (FrameLayout) findViewById(R.id.soccerframelayoutID) == null;

        DBH = new SoccerDBHandler(this, "soccerapp", null, 1);
        builder = new AlertDialog.Builder(this);

        loadAllData query = new loadAllData();
        query.execute("test");
//        while (isLoaded!=true){
//
//        }
        favouritesoccerAdapter = new SoccerNewsAdapter(this);

        soccerAdapter = new SoccerNewsAdapter(this);
        soccerFeedsView = (ListView) findViewById(R.id.messages_viewSoccer);
        soccerFeedsView.setAdapter(soccerAdapter);

        mList1 = DBH.getAllFeeds();

        for (int i = 0; i < mList1.size(); i++) {
            soccerAdapter.add(mList1.get(i), 0);
        }

        soccerFeedsView.setOnItemClickListener((list, item, position, id) -> {
            Bundle dataToPass = new Bundle();

            SoccerFeed feed = (SoccerFeed)  soccerFeedsView.getAdapter().getItem(position);
            //image, date, news article URL and description text
            dataToPass.putString("icon", feed.geticon());
            dataToPass.putString("date", feed.getarticle_date());
            dataToPass.putString("title", feed.getTitle());
            dataToPass.putString("url", feed.getarticle_url());
            dataToPass.putString("description", feed.getarticle_desc());
            dataToPass.putString("imgLink", feed.getimg());
            dataToPass.putBoolean("isToSave", isToSave);
            dataToPass.putString("id", feed.getId());

            if (!isPhone) {
                FragmentManager fm = getSupportFragmentManager();
                newFragment = new SoccerDetailsFragment();
                newFragment.setArguments(dataToPass);
                fm.beginTransaction().replace(R.id.soccerframelayoutID, newFragment).addToBackStack(null).commit();

            } else {
                Intent fragm = new Intent(SoccerFeedsActivity.this, SoccerEmptyActivity.class);
                fragm.putExtras(dataToPass);
                startActivity(fragm);
            }


        });

        final Button receive_Button = (Button) findViewById(R.id.soccerbutton_load_favourite);
        receive_Button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    isToSave=false;
                    ShowToast("Loading your favourite articles!");
                    EditText editText =  (EditText)findViewById(R.id.soccereditTextSearch);
                    editText.setText("");
                    favouritesoccerAdapter = new SoccerNewsAdapter(c);
                    mList = DBH.getAllFeedsFavourite();
                    for (int i = 0; i < mList.size(); i++) {

                        favouritesoccerAdapter.add(mList.get(i), 0);
                    }
                    favouriteView = (ListView) findViewById(R.id.messages_viewSoccer);
                    favouriteView.setAdapter(favouritesoccerAdapter);


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        final Button btnLoadAll = (Button) findViewById(R.id.soccerbutton_load_all);
        btnLoadAll.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    ShowToast("Loading all articles!");
                    EditText editText =  (EditText)findViewById(R.id.soccereditTextSearch);
                    editText.setText("");
                    isToSave=true;

                    soccerAdapter = new SoccerNewsAdapter(c);
                    soccerFeedsView = (ListView) findViewById(R.id.messages_viewSoccer);
                    soccerFeedsView.setAdapter(soccerAdapter);

                    mList1 = DBH.getAllFeeds();

                    for (int i = 0; i < mList1.size(); i++) {
                        soccerAdapter.add(mList1.get(i), 0);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        final Button btnSearch = (Button) findViewById(R.id.soccerbutton_search);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    ShowToast("Searching articles!");
                    EditText editText =  (EditText)findViewById(R.id.soccereditTextSearch);
                    editText.getText();
                    SoccerFeed feed = new SoccerFeed();
                    searchsoccerAdapter = new SoccerNewsAdapter(c);
                    searchsoccerAdapter= (SoccerNewsAdapter) soccerFeedsView.getAdapter();

                    searchAdapter=new SoccerNewsAdapter(c);
                    searchView = (ListView) findViewById(R.id.messages_viewSoccer);
                    searchView.setAdapter(searchAdapter);

                    int size = searchsoccerAdapter.feeds.size();

                    for (int i = 0; i < size; i++) {
                        feed = searchsoccerAdapter.feeds.get(i);
                        if (feed.getTitle().contains(editText.getText())||feed.getarticle_desc().contains(editText.getText())){
                            searchAdapter.feeds.add(feed);
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * show a toast message method
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public void ShowToast(String info) {
        Toast toast = Toast.makeText(this.getApplicationContext(), Html.fromHtml("<font color='purple' ><b>" + info + "</b></font>"), Toast.LENGTH_SHORT);
      //  toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }

    public void reloadFavourite(){
        favouritesoccerAdapter = new SoccerNewsAdapter(c);
        //  favouritesoccerAdapter.removeAll();
        DBH = new SoccerDBHandler(this, "soccerapp", null, 1);
        List<SoccerFeed> feeds = new ArrayList<SoccerFeed>();

        String selectQuery = "SELECT * From favourite_soccer";

        Cursor cursor = DBH.db.rawQuery(selectQuery,null);

        if(cursor.moveToFirst()){
            do {
                SoccerFeed feed = new SoccerFeed();
                feed.setId(cursor.getString( cursor.getColumnIndex("id") ));
                feed.setarticle_date(cursor.getString( cursor.getColumnIndex("Date_time")));
                feed.setTitle(cursor.getString( cursor.getColumnIndex("title")));
                feed.setarticle_desc(cursor.getString( cursor.getColumnIndex("Description")));
                feed.setarticle_url(cursor.getString( cursor.getColumnIndex("URL")));
                feed.setimg(cursor.getString( cursor.getColumnIndex("Thumbnail")));
                feed.seticon(cursor.getString( cursor.getColumnIndex("icon")));

                feeds.add(feed);
            }while (cursor.moveToNext());
        }

        for (int i = 0; i < feeds.size(); i++) {

            favouritesoccerAdapter.add(feeds.get(i), 0);
        }
        favouriteView = (ListView) findViewById(R.id.messages_viewSoccer);
        favouriteView.setAdapter(favouritesoccerAdapter);

    }

    /**
     * load all the articles from feed link, it is AsyncTas
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    protected class loadAllData extends AsyncTask<String,Integer,String> {
        public void loadAll() {
            isLoaded=false;

         //  DBH.getDB().execSQL("delete from soccer");
        //   DBH.getDB().execSQL("delete from favourite_soccer");

            HttpsURLConnection con = null;
            HttpURLConnection con_imager = null;
            Bitmap image = null;

            try {
                URL u = new URL("https://www.goal.com/feeds/en/news");
                DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
                Document document = documentBuilder.parse(new InputSource(u.openStream()));
                document.getDocumentElement().normalize();
                NodeList nodlist = document.getElementsByTagName("item");

               // pb.setIndeterminate(true);
                pb.setMax(nodlist.getLength());

                Node node = null;
                Element eElement = null;
                NodeList thumbList = null;
                Element thumbElement =null;
                String thumbURL = null;

                SoccerFeed feed = new SoccerFeed();
                for (int itr = 0; itr < nodlist.getLength(); itr++) {
                    pb.setProgress(itr+1);
                    node = nodlist.item(itr);
                    if (node.getNodeType() == Node.ELEMENT_NODE) {
                        eElement = (Element) node;
                        String Query = "select * from soccer where URL='"+eElement.getElementsByTagName("link").item(0).getTextContent().replace("'","''")+"'";
                        Cursor cursor = DBH.getDB().rawQuery(Query, null);
                        if(cursor.getCount() <= 0){
                            feed.setId(DBH.getNextId());
                            feed.setarticle_date(eElement.getElementsByTagName("pubDate").item(0).getTextContent().replace("'","''"));
                            feed.setTitle(eElement.getElementsByTagName("title").item(0).getTextContent().replace("'","''"));
                            feed.setarticle_desc(eElement.getElementsByTagName("description").item(0).getTextContent().replace("'","''"));
                            feed.setarticle_url(eElement.getElementsByTagName("link").item(0).getTextContent().replace("'","''"));

                            thumbList = eElement.getElementsByTagName("media:thumbnail");
                            thumbElement = (Element)thumbList.item(0);
                            thumbURL = thumbElement.getAttribute("url");
                            feed.setimg(thumbURL.replace("'","''"));

                            URL url = null;
                            try {
                                url = new URL(feed.getimg());
                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            }
                            try {
                                con_imager = (HttpURLConnection) url.openConnection();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            try {
                                con_imager.connect();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            int responseCode = 0;
                            try {
                                responseCode = con_imager.getResponseCode();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            if (responseCode == 200) {
                                image = BitmapFactory.decodeStream(con_imager.getInputStream());
                                feed.seticon(encodeTobase64(ThumbnailUtils.extractThumbnail(image, 47, 47)));
                            }
                            DBH.insertFeed(feed);
                        }
                    }
                }
            } catch (IOException ioException) {
                ioException.printStackTrace();
            } catch (ParserConfigurationException parserConfigurationException) {
                parserConfigurationException.printStackTrace();
            } catch (SAXException saxException) {
                saxException.printStackTrace();
            } catch (Exception e){
                e.printStackTrace();
            } finally {
                if (con != null) {
                    try {
                        con.disconnect();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }

            isLoaded=true;
        }

        public void onCreate(SQLiteDatabase db) {

        }
        @Override
        protected void onPreExecute() {
            pb= new ProgressBar(c,null,android.R.attr.progressBarStyleHorizontal);
                    root = (ViewGroup) findViewById(android.R.id.content);
                    root.addView(pb);
        }

        protected void  onPostExecute(String result) {
            pb.setVisibility(View.GONE);
            root.removeView(pb);

        }


        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }

        @Override
        protected String doInBackground(String... strings) {
            loadAll();
            return null;
        }
    }

    /**
     * encode method to convert image to a string byte[]
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public static String encodeTobase64(Bitmap image) {
        Bitmap immagex = image;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        immagex.compress(Bitmap.CompressFormat.PNG, 90, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);
        return imageEncoded;
    }

    /**
     * reverse method to convert a string to bitmap
     *
     * @author – Hong Liang
     * @version – 2021.3
     * @param –
     * @return –
     * @since – 1.0
     */
    public static Bitmap decodeBase64(String input) {
        byte[] decodedByte = Base64.decode(input, 0);
        return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
    }
}