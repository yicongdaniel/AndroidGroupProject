package com.cst2335.groupproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

/**
 * A class that holds and creates the table using the columns created in song_info class
 * Two tables are created one is for holding search results and another table is for adding songs to favorite list
 *
 */
public class Songster_DB extends SQLiteOpenHelper {
    /**
     * static variable holds the database name which is songDB
     */
    protected final static  String DATABASE_NAME = "SongDB";

    /**
     * variable hold the version of teh database
     */
    protected final static int VERSION_NUM = 8;


    public Songster_DB(@Nullable Context context) {

        super(context, DATABASE_NAME, null, VERSION_NUM);
    }

    /**
     * creates two tables one is for search results and another for
     * @param db execute the SQL on variable db using create table on the columns created in song_info class
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(String.format("CREATE TABLE %s " +
                        "(%s INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        " %s text," +" %s Integer); ", Songster_Info.TABLE_NAME_FAVORITE, Songster_Info.COL_ID, Songster_Info.COL_TITLE, Songster_Info.COL_IDArt));

        db.execSQL(String.format("CREATE TABLE %s " +
                        "(%s INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        " %s text," +" %s Integer); ", Songster_Info.TABLE_NAME_SEARCH_RESULT, Songster_Info.COL_ID, Songster_Info.COL_TITLE, Songster_Info.COL_IDArt));
    }

    /**
     *
     * @param db variable to executes the table
     * @param oldVersion
     * @param newVersion
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL( "DROP TABLE IF EXISTS " + Songster_Info.TABLE_NAME_SEARCH_RESULT);
        db.execSQL( "DROP TABLE IF EXISTS " + Songster_Info.TABLE_NAME_FAVORITE);

        //Create the new table:
        onCreate(db);
    }
}